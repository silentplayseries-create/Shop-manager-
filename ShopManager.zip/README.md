# Shop Manager — Phase 1

Offline-first Android app for furniture (and other) shop management.
Built with **Kotlin + Jetpack Compose + Room (SQLite)** — no TinyDB, since
Room is the "Future Version" database from the spec; starting there avoids
a data migration later.

## What's implemented (Phase 1 scope: Dashboard, Orders, Customers, DB)

- **Room database**: `Customer`, `Order`, `Payment` entities, fully offline
- **Customers**: add, search (name/mobile), list with running Total Due
- **Orders**: create with live auto-calculation (qty × price − discount + GST),
  advance/balance tracking, mark-as-delivered
- **Dashboard**: Today's Sale, Today's Orders, Pending Delivery, Pending
  Payments, Total Customers (all live-updating via Room `Flow`)
- **Customer totals sync automatically**: creating/editing/deleting an order
  or recording a payment updates the customer's Total Purchase / Paid / Due
  via a delta update (no expensive re-summing)
- Dark blue + white theme, rounded corners, large fonts, bottom nav
  (Dashboard / Orders / Customers) per Section 19 of the spec

## Not yet built (later phases per your roadmap)

- Stock module, Reports, Calculator screens (Phase 2)
- Voice Assistant, Backup/Export (Phase 3)
- AI chat, Cloud sync, WhatsApp invoice, Barcode (Phase 4)
- Customer detail/history screen, Payment recording UI, PIN/fingerprint lock

These are stubbed as empty nav routes (`Routes.STOCK`, `Routes.REPORTS`, etc.
in `NavGraph.kt`) so wiring in new screens later is a small, contained change.

## How to open and run

1. Install **Android Studio** (Koala or newer).
2. Open this `ShopManager/` folder as a project (File → Open).
3. Let Gradle sync — it will download dependencies (Compose, Room, Navigation)
   on first sync, so you'll need internet the first time only.
4. Run on an emulator or a real device (minSdk 24 = Android 7.0+).

No manual setup needed — the Room database file is created automatically
on first launch at app-private storage, fully offline after that.

## Project structure

```
app/src/main/java/com/shopmanager/app/
├── data/
│   ├── local/          # Room entities, DAOs, AppDatabase, type converters
│   └── repository/      # Business logic: keeps Customer totals in sync
├── viewmodel/            # One ViewModel per screen group + manual DI factory
├── ui/
│   ├── screens/          # dashboard/, customer/, order/
│   ├── components/       # Reusable StatCard, QuickActionButton
│   ├── navigation/       # NavGraph + bottom-nav app shell
│   └── theme/            # Colors, typography, shapes
└── AppContainer.kt        # Manual DI container (no Hilt needed yet)
```

## Note on this build

This code was written without a live Android SDK/Gradle environment to
compile against, so please do a first Gradle sync in Android Studio and
let me know if anything doesn't build — happy to fix immediately.
