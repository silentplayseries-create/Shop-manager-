package com.shopmanager.app.ui.screens.customer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.viewmodel.CustomerViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.util.Locale

@Composable
fun CustomerListScreen(
    container: AppContainer,
    onAddCustomer: () -> Unit,
    onCustomerClick: (Customer) -> Unit
) {
    val viewModel: CustomerViewModel = viewModel(factory = ViewModelFactory(container))
    val customers by viewModel.customers.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    // Customer pending delete confirmation - Section 7: Delete
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAddCustomer) {
                Icon(Icons.Default.Add, contentDescription = "Add Customer")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Customers",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = viewModel::onSearchQueryChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search by name or mobile") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (customers.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Koi customer nahi mila", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(customers, key = { it.id }) { customer ->
                        CustomerRow(
                            customer = customer,
                            rupeeFormat = rupeeFormat,
                            onClick = { onCustomerClick(customer) },
                            onDeleteClick = { customerToDelete = customer }
                        )
                    }
                }
            }
        }
    }

    // Confirmation dialog so a customer can't be deleted with an accidental tap
    customerToDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("Delete Customer?") },
            text = { Text("${customer.name} ko delete karna hai? Ye undo nahi ho sakta.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteCustomer(customer)
                    customerToDelete = null
                }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun CustomerRow(
    customer: Customer,
    rupeeFormat: NumberFormat,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(customer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(customer.mobile, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (customer.totalDue > 0) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("Due", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        rupeeFormat.format(customer.totalDue),
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            IconButton(onClick = onDeleteClick) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "Delete ${customer.name}",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
