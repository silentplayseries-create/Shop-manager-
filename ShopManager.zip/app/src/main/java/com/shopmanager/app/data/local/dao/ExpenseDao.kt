package com.shopmanager.app.data.local.dao

import androidx.room.*
import com.shopmanager.app.data.local.entity.Expense
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Expense>>

    @Query("SELECT COALESCE(SUM(amount), 0.0) FROM expenses WHERE createdAt BETWEEN :start AND :end")
    fun getTotalBetween(start: Long, end: Long): Flow<Double>

    @Insert
    suspend fun insert(expense: Expense): Long

    @Delete
    suspend fun delete(expense: Expense)

    @Query("SELECT * FROM expenses")
    suspend fun getAllOnce(): List<Expense>

    @Query("DELETE FROM expenses")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(expenses: List<Expense>)
}
