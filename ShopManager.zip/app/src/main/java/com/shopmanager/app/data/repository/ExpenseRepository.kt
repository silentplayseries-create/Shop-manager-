package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.ExpenseDao
import com.shopmanager.app.data.local.entity.Expense
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class ExpenseRepository(private val expenseDao: ExpenseDao) {

    fun getAll(): Flow<List<Expense>> = expenseDao.getAll()

    suspend fun add(expense: Expense): Long = expenseDao.insert(expense)

    suspend fun delete(expense: Expense) = expenseDao.delete(expense)

    fun getThisMonthTotal(): Flow<Double> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        val end = System.currentTimeMillis()
        return expenseDao.getTotalBetween(start, end)
    }
}
