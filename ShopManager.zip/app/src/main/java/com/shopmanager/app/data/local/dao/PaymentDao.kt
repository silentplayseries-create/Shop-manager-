package com.shopmanager.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.shopmanager.app.data.local.entity.Payment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {

    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getForCustomer(customerId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE orderId = :orderId ORDER BY createdAt DESC")
    fun getForOrder(orderId: Long): Flow<List<Payment>>

    @Insert
    suspend fun insert(payment: Payment): Long

    // --- Backup/Restore (Section 16) ---

    @Query("SELECT * FROM payments")
    suspend fun getAllOnce(): List<Payment>

    @Query("DELETE FROM payments")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(payments: List<Payment>)
}
