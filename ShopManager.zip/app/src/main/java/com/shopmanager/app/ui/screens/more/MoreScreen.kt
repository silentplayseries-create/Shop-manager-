package com.shopmanager.app.ui.screens.more

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shopmanager.app.ui.theme.AccentBlue
import com.shopmanager.app.ui.theme.AccentGreen
import com.shopmanager.app.ui.theme.AccentIndigo
import com.shopmanager.app.ui.theme.AccentOrange
import com.shopmanager.app.ui.theme.AccentPink
import com.shopmanager.app.ui.theme.AccentRed

private data class MoreItem(
    val label: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: androidx.compose.ui.graphics.Color,
    val onClick: () -> Unit
)

@Composable
fun MoreScreen(
    onPayments: () -> Unit,
    onDelivery: () -> Unit,
    onExpenses: () -> Unit,
    onSuppliers: () -> Unit,
    onStaff: () -> Unit,
    onCalculator: () -> Unit,
    onVoiceAssistant: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit
) {
    val items = listOf(
        MoreItem("Search", "Customer, order, stock, sab kuch dhundo", Icons.Default.Search, AccentBlue, onSearch),
        MoreItem("Payments", "Sab payments dekho aur naya add karo", Icons.Default.Payments, AccentGreen, onPayments),
        MoreItem("Delivery", "Pending aur out-for-delivery orders", Icons.Default.LocalShipping, AccentOrange, onDelivery),
        MoreItem("Expenses", "Rent, salary, transport, etc.", Icons.Default.Receipt, AccentRed, onExpenses),
        MoreItem("Suppliers", "Supplier list aur pending bills", Icons.Default.Storefront, AccentIndigo, onSuppliers),
        MoreItem("Staff", "Staff aur attendance", Icons.Default.Badge, AccentIndigo, onStaff),
        MoreItem("Calculator", "Normal, GST, Discount, Profit, EMI", Icons.Default.Calculate, AccentGreen, onCalculator),
        MoreItem("Voice Assistant", "Bol ke sale check karo", Icons.Default.Mic, AccentPink, onVoiceAssistant),
        MoreItem("Settings", "Shop details, theme, backup, PIN lock", Icons.Default.Settings, AccentBlue, onSettings)
    )

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("More", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items.forEach { item ->
                Card(onClick = item.onClick, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(item.accentColor.copy(alpha = 0.15f), shape = RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(item.icon, contentDescription = item.label, tint = item.accentColor)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(item.subtitle, style = MaterialTheme.typography.bodyMedium)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null)
                    }
                }
            }
        }
    }
}
