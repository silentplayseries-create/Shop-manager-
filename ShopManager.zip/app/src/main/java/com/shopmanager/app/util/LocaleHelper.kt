package com.shopmanager.app.util

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/**
 * Section 4 (Languages) / Section 17 (Settings > Language): per-app language
 * switching that works independently of the phone's system language, using
 * AndroidX's per-app language API (backed by the OS on Android 13+, and by
 * AppCompat's own mechanism on older versions).
 */
object LocaleHelper {

    enum class AppLanguage(val tag: String, val displayName: String) {
        DEFAULT("", "Default (Hinglish)"),
        HINDI("hi", "हिंदी (Hindi)"),
        BHOJPURI("bho", "भोजपुरी (Bhojpuri)")
    }

    fun setLanguage(language: AppLanguage) {
        val locales = if (language == AppLanguage.DEFAULT) {
            LocaleListCompat.getEmptyLocaleList()
        } else {
            LocaleListCompat.forLanguageTags(language.tag)
        }
        AppCompatDelegate.setApplicationLocales(locales)
    }

    fun currentLanguage(): AppLanguage {
        val tag = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        return AppLanguage.entries.find { it.tag.isNotEmpty() && tag.startsWith(it.tag) } ?: AppLanguage.DEFAULT
    }
}
