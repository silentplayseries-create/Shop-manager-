package com.shopmanager.app.ui.components.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

data class LinePoint(val label: String, val value: Double)

/** Simple line chart: points connected by straight lines, with a filled area beneath. */
@Composable
fun LineChart(
    points: List<LinePoint>,
    lineColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    chartHeight: Dp = 160.dp
) {
    if (points.size < 2) {
        Text("Chart ke liye kam se kam 2 data points chahiye", style = MaterialTheme.typography.bodyMedium)
        return
    }
    val maxValue = (points.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)
    val minValue = (points.minOfOrNull { it.value } ?: 0.0).coerceAtMost(0.0)
    val range = (maxValue - minValue).coerceAtLeast(1.0)

    Column(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxWidth().height(chartHeight)) {
            val stepX = size.width / (points.size - 1)
            val offsets = points.mapIndexed { index, point ->
                val fraction = ((point.value - minValue) / range).toFloat()
                Offset(x = index * stepX, y = size.height - (size.height * fraction))
            }

            // Filled area under the line
            val fillPath = androidx.compose.ui.graphics.Path().apply {
                moveTo(offsets.first().x, size.height)
                offsets.forEach { lineTo(it.x, it.y) }
                lineTo(offsets.last().x, size.height)
                close()
            }
            drawPath(fillPath, color = lineColor.copy(alpha = 0.15f))

            // Line itself
            for (i in 0 until offsets.size - 1) {
                drawLine(
                    color = lineColor,
                    start = offsets[i],
                    end = offsets[i + 1],
                    strokeWidth = 5f,
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            }
            // Points
            offsets.forEach { drawCircle(color = lineColor, radius = 6f, center = it) }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            points.forEach { point ->
                Text(
                    text = point.label,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.width(0.dp).weight(1f),
                    maxLines = 1
                )
            }
        }
    }
}
