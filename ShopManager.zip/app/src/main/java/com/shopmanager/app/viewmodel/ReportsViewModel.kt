package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.StockItem
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import com.shopmanager.app.data.repository.StockRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class ReportRange { TODAY, WEEK, MONTH, YEAR }

data class ProfitResult(val totalProfit: Double, val ordersMatched: Int, val ordersUnmatched: Int)

class ReportsViewModel(
    private val orderRepository: OrderRepository,
    customerRepository: CustomerRepository,
    private val stockRepository: StockRepository
) : ViewModel() {

    val orders: StateFlow<List<Order>> = orderRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<Customer>> = customerRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stockItems: StateFlow<List<StockItem>> = stockRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _profitResult = MutableStateFlow<ProfitResult?>(null)
    val profitResult: StateFlow<ProfitResult?> = _profitResult.asStateFlow()

    private val _isCalculatingProfit = MutableStateFlow(false)
    val isCalculatingProfit: StateFlow<Boolean> = _isCalculatingProfit.asStateFlow()

    fun salesTotalFor(range: ReportRange): Double {
        val (start, end) = rangeBounds(range)
        return orders.value.filter { it.createdAt in start..end }.sumOf { it.total }
    }

    fun orderCountFor(range: ReportRange): Int {
        val (start, end) = rangeBounds(range)
        return orders.value.count { it.createdAt in start..end }
    }

    /**
     * Approximate profit: matches each order's furniture name to a Stock
     * item (Section 10) to find its buying price, then profit = order total
     * minus (buying price x quantity). Orders with no matching stock item
     * are skipped and reported separately, since there's no buying-price
     * source for a free-text furniture name that was never added to Stock.
     */
    fun calculateProfit() {
        viewModelScope.launch {
            _isCalculatingProfit.value = true
            var totalProfit = 0.0
            var matched = 0
            var unmatched = 0
            for (order in orders.value) {
                val stockItem = stockRepository.findByName(order.furnitureName)
                if (stockItem != null) {
                    totalProfit += order.total - (stockItem.buyingPrice * order.quantity)
                    matched++
                } else {
                    unmatched++
                }
            }
            _profitResult.value = ProfitResult(totalProfit, matched, unmatched)
            _isCalculatingProfit.value = false
        }
    }

    private fun rangeBounds(range: ReportRange): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)

        when (range) {
            ReportRange.TODAY -> { /* today's start of day already set */ }
            ReportRange.WEEK -> cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
            ReportRange.MONTH -> cal.set(Calendar.DAY_OF_MONTH, 1)
            ReportRange.YEAR -> cal.set(Calendar.DAY_OF_YEAR, 1)
        }
        val start = cal.timeInMillis
        val end = System.currentTimeMillis()
        return start to end
    }
}
