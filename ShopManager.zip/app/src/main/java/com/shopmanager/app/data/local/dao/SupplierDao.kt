package com.shopmanager.app.data.local.dao

import androidx.room.*
import com.shopmanager.app.data.local.entity.Supplier
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierDao {

    @Query("SELECT * FROM suppliers ORDER BY name ASC")
    fun getAll(): Flow<List<Supplier>>

    @Query("""
        SELECT * FROM suppliers
        WHERE name LIKE '%' || :query || '%' OR mobile LIKE '%' || :query || '%'
        ORDER BY name ASC
    """)
    fun search(query: String): Flow<List<Supplier>>

    @Insert
    suspend fun insert(supplier: Supplier): Long

    @Update
    suspend fun update(supplier: Supplier)

    @Delete
    suspend fun delete(supplier: Supplier)

    @Query("SELECT * FROM suppliers")
    suspend fun getAllOnce(): List<Supplier>

    @Query("DELETE FROM suppliers")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(suppliers: List<Supplier>)
}
