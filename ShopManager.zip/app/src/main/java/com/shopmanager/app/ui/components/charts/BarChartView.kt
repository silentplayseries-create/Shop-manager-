package com.shopmanager.app.ui.components.charts

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class BarDatum(val label: String, val value: Double, val displayValue: String)

/** Simple horizontal bar chart - one bar per row, bars scaled to the max value. */
@Composable
fun HorizontalBarChart(
    data: List<BarDatum>,
    barColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) return
    val maxValue = (data.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)

    Column(modifier = modifier) {
        data.forEach { datum ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                Text(
                    text = datum.label,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.width(90.dp)
                )
                Box(modifier = Modifier.weight(1f).height(22.dp)) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val fraction = (datum.value / maxValue).toFloat().coerceIn(0f, 1f)
                        drawRect(
                            color = barColor,
                            size = androidx.compose.ui.geometry.Size(size.width * fraction, size.height)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = datum.displayValue,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.width(80.dp)
                )
            }
        }
    }
}

/** Simple vertical bar chart with a baseline and value labels on top of each bar. */
@Composable
fun VerticalBarChart(
    data: List<BarDatum>,
    barColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    chartHeight: androidx.compose.ui.unit.Dp = 160.dp
) {
    if (data.isEmpty()) return
    val maxValue = (data.maxOfOrNull { it.value } ?: 1.0).coerceAtLeast(1.0)

    Row(
        modifier = modifier.height(chartHeight + 44.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        data.forEach { datum ->
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = datum.displayValue,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Canvas(modifier = Modifier.width(28.dp).height(chartHeight)) {
                    val fraction = (datum.value / maxValue).toFloat().coerceIn(0f, 1f)
                    val barHeight = size.height * fraction
                    drawRect(
                        color = barColor,
                        topLeft = androidx.compose.ui.geometry.Offset(0f, size.height - barHeight),
                        size = androidx.compose.ui.geometry.Size(size.width, barHeight)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = datum.label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1
                )
            }
        }
    }
}
