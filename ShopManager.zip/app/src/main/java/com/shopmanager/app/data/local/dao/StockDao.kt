package com.shopmanager.app.data.local.dao

import androidx.room.*
import com.shopmanager.app.data.local.entity.StockItem
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {

    @Query("SELECT * FROM stock_items ORDER BY furnitureName ASC")
    fun getAll(): Flow<List<StockItem>>

    @Query("""
        SELECT * FROM stock_items
        WHERE furnitureName LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%'
        ORDER BY furnitureName ASC
    """)
    fun search(query: String): Flow<List<StockItem>>

    @Query("SELECT * FROM stock_items WHERE quantity <= minQuantity ORDER BY quantity ASC")
    fun getLowStock(): Flow<List<StockItem>>

    @Query("SELECT COUNT(*) FROM stock_items WHERE quantity <= minQuantity")
    fun getLowStockCount(): Flow<Int>

    @Query("SELECT * FROM stock_items WHERE id = :id")
    suspend fun getById(id: Long): StockItem?

    // Used by Reports (Profit Report) to match an order's furniture name
    // back to its buying price.
    @Query("SELECT * FROM stock_items WHERE LOWER(furnitureName) = LOWER(:name) LIMIT 1")
    suspend fun findByName(name: String): StockItem?

    @Insert
    suspend fun insert(item: StockItem): Long

    @Update
    suspend fun update(item: StockItem)

    @Delete
    suspend fun delete(item: StockItem)

    // --- Backup/Restore (Section 16) ---

    @Query("SELECT * FROM stock_items")
    suspend fun getAllOnce(): List<StockItem>

    @Query("DELETE FROM stock_items")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(items: List<StockItem>)
}
