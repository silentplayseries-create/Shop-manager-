package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.AttendanceDao
import com.shopmanager.app.data.local.dao.StaffDao
import com.shopmanager.app.data.local.entity.Attendance
import com.shopmanager.app.data.local.entity.AttendanceStatus
import com.shopmanager.app.data.local.entity.Staff
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StaffRepository(
    private val staffDao: StaffDao,
    private val attendanceDao: AttendanceDao
) {
    private val dayKeyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun getAll(): Flow<List<Staff>> = staffDao.getAll()

    suspend fun add(staff: Staff): Long = staffDao.insert(staff)

    suspend fun update(staff: Staff) = staffDao.update(staff)

    suspend fun delete(staff: Staff) = staffDao.delete(staff)

    fun todayKey(): String = dayKeyFormat.format(Date())

    fun getAttendanceForDay(dayKey: String): Flow<List<Attendance>> = attendanceDao.getForDay(dayKey)

    fun getPresentCountToday(): Flow<Int> = attendanceDao.getPresentCountForDay(todayKey())

    /** Marks (or re-marks) a staff member's attendance for today - real upsert, not relying on PK conflict. */
    suspend fun markAttendance(staffId: Long, status: AttendanceStatus, dayKey: String = todayKey()) {
        val existing = attendanceDao.getForStaffAndDay(staffId, dayKey)
        if (existing != null) {
            attendanceDao.update(existing.copy(status = status, markedAt = System.currentTimeMillis()))
        } else {
            attendanceDao.insert(Attendance(staffId = staffId, dayKey = dayKey, status = status))
        }
    }
}
