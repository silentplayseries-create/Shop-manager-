package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Suppliers Module (added per request, mirrors Customer module's shape).
 */
@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val mobile: String,
    val address: String = "",
    val gstNumber: String = "",
    val pendingBills: Double = 0.0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
