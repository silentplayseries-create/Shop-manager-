package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class AttendanceStatus { PRESENT, ABSENT, HALF_DAY, LEAVE }

/**
 * Staff Module - daily attendance. One row per staff member per calendar
 * day (dayKey = "yyyy-MM-dd"), so marking attendance twice the same day
 * updates rather than duplicates.
 */
@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = Staff::class,
            parentColumns = ["id"],
            childColumns = ["staffId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("staffId"), Index("dayKey")]
)
data class Attendance(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val staffId: Long,
    val dayKey: String,
    val status: AttendanceStatus,
    val markedAt: Long = System.currentTimeMillis()
)
