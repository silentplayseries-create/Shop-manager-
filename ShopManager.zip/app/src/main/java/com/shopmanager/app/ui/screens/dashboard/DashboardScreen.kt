package com.shopmanager.app.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.ui.components.QuickActionButton
import com.shopmanager.app.ui.components.StatCard
import com.shopmanager.app.ui.theme.AccentBlue
import com.shopmanager.app.ui.theme.AccentGreen
import com.shopmanager.app.ui.theme.AccentOrange
import com.shopmanager.app.ui.theme.AccentPink
import com.shopmanager.app.ui.theme.AccentPurple
import com.shopmanager.app.ui.theme.AccentTeal
import com.shopmanager.app.viewmodel.DashboardViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    container: AppContainer,
    onNewOrder: () -> Unit,
    onCustomers: () -> Unit,
    onStock: () -> Unit,
    onReports: () -> Unit,
    onCalculator: () -> Unit,
    onVoiceAssistant: () -> Unit,
    onSettings: () -> Unit
) {
    val viewModel: DashboardViewModel = viewModel(factory = ViewModelFactory(container))
    val state by viewModel.uiState.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    val ownerName = container.settingsPrefs.ownerName
    val shopName = container.settingsPrefs.shopName

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Good Morning"
            hour < 17 -> "Good Afternoon"
            else -> "Good Evening"
        }
    }
    val dateStr = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (ownerName.isNotBlank()) "$greeting, $ownerName" else greeting,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = shopName.ifBlank { "Shop Manager" },
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section 6: Dashboard stats - each with its own accent color
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.height(360.dp)
        ) {
            item {
                StatCard(
                    label = "Today's Sale",
                    value = rupeeFormat.format(state.todaySale),
                    icon = Icons.Default.CurrencyRupee,
                    accentColor = AccentGreen
                )
            }
            item {
                StatCard(
                    label = "Today's Orders",
                    value = state.todayOrders.toString(),
                    icon = Icons.Default.ShoppingCart,
                    accentColor = AccentBlue
                )
            }
            item {
                StatCard(
                    label = "Pending Delivery",
                    value = state.pendingDelivery.toString(),
                    icon = Icons.Default.LocalShipping,
                    accentColor = AccentOrange,
                    isAlert = state.pendingDelivery > 0
                )
            }
            item {
                StatCard(
                    label = "Pending Payments",
                    value = rupeeFormat.format(state.pendingPayments),
                    icon = Icons.Default.Warning,
                    accentColor = AccentPink,
                    isAlert = state.pendingPayments > 0
                )
            }
            item {
                StatCard(
                    label = "Total Customers",
                    value = state.totalCustomers.toString(),
                    icon = Icons.Default.People,
                    accentColor = AccentPurple
                )
            }
            item {
                StatCard(
                    label = "Low Stock Alert",
                    value = state.lowStockCount.toString(),
                    icon = Icons.Default.Inventory2,
                    accentColor = AccentTeal,
                    isAlert = state.lowStockCount > 0
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Quick Actions",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Section 6: Quick Buttons - each with its own accent color chip
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            item { QuickActionButton("New Order", Icons.Default.AddShoppingCart, AccentBlue, onNewOrder) }
            item { QuickActionButton("Customers", Icons.Default.People, AccentPurple, onCustomers) }
            item { QuickActionButton("Stock", Icons.Default.Inventory2, AccentTeal, onStock) }
            item { QuickActionButton("Reports", Icons.Default.Assessment, AccentOrange, onReports) }
            item { QuickActionButton("Calculator", Icons.Default.Calculate, AccentGreen, onCalculator) }
            item { QuickActionButton("Voice Assistant", Icons.Default.Mic, AccentPink, onVoiceAssistant) }
        }
    }
}
