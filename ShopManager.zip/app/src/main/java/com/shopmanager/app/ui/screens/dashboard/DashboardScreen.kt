package com.shopmanager.app.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.ui.components.QuickActionButton
import com.shopmanager.app.ui.components.StatCard
import com.shopmanager.app.ui.theme.AccentBlue
import com.shopmanager.app.ui.theme.AccentGreen
import com.shopmanager.app.ui.theme.AccentIndigo
import com.shopmanager.app.ui.theme.AccentOrange
import com.shopmanager.app.ui.theme.AccentPink
import com.shopmanager.app.ui.theme.AccentPurple
import com.shopmanager.app.ui.theme.AccentRed
import com.shopmanager.app.ui.theme.AccentTeal
import com.shopmanager.app.viewmodel.DashboardViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class StatCardData(
    val label: String,
    val value: String,
    val icon: ImageVector,
    val accentColor: Color,
    val isAlert: Boolean = false
)

private data class QuickActionData(
    val label: String,
    val icon: ImageVector,
    val accentColor: Color,
    val onClick: () -> Unit
)

@Composable
fun DashboardScreen(
    container: AppContainer,
    onNewOrder: () -> Unit,
    onCustomers: () -> Unit,
    onStock: () -> Unit,
    onReports: () -> Unit,
    onCalculator: () -> Unit,
    onVoiceAssistant: () -> Unit,
    onSettings: () -> Unit,
    onPayments: () -> Unit,
    onDelivery: () -> Unit,
    onExpenses: () -> Unit,
    onSuppliers: () -> Unit,
    onStaff: () -> Unit
) {
    val viewModel: DashboardViewModel = viewModel(factory = ViewModelFactory(container))
    val state by viewModel.uiState.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    val ownerName = container.settingsPrefs.ownerName
    val shopName = container.settingsPrefs.shopName

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Good Morning"
            hour < 17 -> "Good Afternoon"
            else -> "Good Evening"
        }
    }
    val dateStr = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date()) }

    val statCards = listOf(
        StatCardData("Today's Sale", rupeeFormat.format(state.todaySale), Icons.Default.CurrencyRupee, AccentGreen),
        StatCardData("Today's Orders", state.todayOrders.toString(), Icons.Default.ShoppingCart, AccentBlue),
        StatCardData("Pending Delivery", state.pendingDelivery.toString(), Icons.Default.LocalShipping, AccentOrange, state.pendingDelivery > 0),
        StatCardData("Pending Payments", rupeeFormat.format(state.pendingPayments), Icons.Default.Warning, AccentPink, state.pendingPayments > 0),
        StatCardData("Total Customers", state.totalCustomers.toString(), Icons.Default.People, AccentPurple),
        StatCardData("Low Stock Alert", state.lowStockCount.toString(), Icons.Default.Inventory2, AccentTeal, state.lowStockCount > 0),
        StatCardData("Staff Present", state.staffPresentToday.toString(), Icons.Default.Badge, AccentIndigo)
    )

    val quickActions = listOf(
        QuickActionData("New Order", Icons.Default.AddShoppingCart, AccentBlue, onNewOrder),
        QuickActionData("Customers", Icons.Default.People, AccentPurple, onCustomers),
        QuickActionData("Stock", Icons.Default.Inventory2, AccentTeal, onStock),
        QuickActionData("Payments", Icons.Default.Payments, AccentGreen, onPayments),
        QuickActionData("Delivery", Icons.Default.LocalShipping, AccentOrange, onDelivery),
        QuickActionData("Expenses", Icons.Default.Receipt, AccentRed, onExpenses),
        QuickActionData("Suppliers", Icons.Default.Storefront, AccentIndigo, onSuppliers),
        QuickActionData("Staff", Icons.Default.Badge, AccentIndigo, onStaff),
        QuickActionData("Reports", Icons.Default.Assessment, AccentOrange, onReports),
        QuickActionData("Calculator", Icons.Default.Calculate, AccentGreen, onCalculator),
        QuickActionData("Voice Assistant", Icons.Default.Mic, AccentPink, onVoiceAssistant)
    )

    // The whole screen scrolls as one Column. Grids are built manually with
    // chunked Rows (not LazyVerticalGrid) because a lazy grid inside a
    // scrollable Column needs a fixed height and clips content on smaller
    // screens - a plain Column of Rows just grows naturally and scrolls fine.
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (ownerName.isNotBlank()) "$greeting, $ownerName" else greeting,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = shopName.ifBlank { "Shop Manager" },
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Section 6: Dashboard stats - 2 per row
        statCards.chunked(2).forEach { rowItems ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                rowItems.forEach { card ->
                    StatCard(
                        label = card.label,
                        value = card.value,
                        icon = card.icon,
                        accentColor = card.accentColor,
                        isAlert = card.isAlert,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Quick Actions",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Section 6: Quick Buttons - 3 per row
        quickActions.chunked(3).forEach { rowItems ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
                rowItems.forEach { action ->
                    QuickActionButton(
                        label = action.label,
                        icon = action.icon,
                        accentColor = action.accentColor,
                        onClick = action.onClick,
                        modifier = Modifier.weight(1f)
                    )
                }
                repeat(3 - rowItems.size) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
