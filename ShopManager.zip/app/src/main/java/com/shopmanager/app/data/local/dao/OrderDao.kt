package com.shopmanager.app.data.local.dao

import androidx.room.*
import com.shopmanager.app.data.local.entity.Order
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getForCustomer(customerId: Long): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getById(id: Long): Order?

    @Insert
    suspend fun insert(order: Order): Long

    @Update
    suspend fun update(order: Order)

    @Delete
    suspend fun delete(order: Order)

    // --- Dashboard queries (Master Spec Section 6) ---

    @Query("SELECT COALESCE(SUM(total), 0.0) FROM orders WHERE createdAt BETWEEN :dayStart AND :dayEnd")
    fun getTodaySaleTotal(dayStart: Long, dayEnd: Long): Flow<Double>

    @Query("SELECT COUNT(*) FROM orders WHERE createdAt BETWEEN :dayStart AND :dayEnd")
    fun getTodayOrderCount(dayStart: Long, dayEnd: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM orders WHERE status = 'PENDING'")
    fun getPendingDeliveryCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(balance), 0.0) FROM orders WHERE balance > 0")
    fun getTotalPendingPayments(): Flow<Double>

    // --- Reports (Master Spec Section 11) ---

    @Query("SELECT * FROM orders WHERE createdAt BETWEEN :start AND :end ORDER BY createdAt DESC")
    fun getOrdersBetween(start: Long, end: Long): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE balance > 0 ORDER BY createdAt DESC")
    fun getOrdersWithPendingBalance(): Flow<List<Order>>
}
