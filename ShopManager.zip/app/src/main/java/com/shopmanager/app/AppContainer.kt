package com.shopmanager.app

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import com.shopmanager.app.data.local.AppDatabase
import com.shopmanager.app.data.local.SettingsPrefs
import com.shopmanager.app.data.local.ThemeMode
import com.shopmanager.app.data.repository.BackupRepository
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import com.shopmanager.app.data.repository.PaymentRepository
import com.shopmanager.app.data.repository.StockRepository

/**
 * Lightweight manual DI container. Keeps things simple - no need to pull
 * in Hilt/Koin for an app this size.
 */
class AppContainer(context: Context) {
    private val db = AppDatabase.getInstance(context)

    val customerRepository = CustomerRepository(db.customerDao())
    val orderRepository = OrderRepository(db.orderDao(), db.customerDao())
    val paymentRepository = PaymentRepository(db.paymentDao(), db.orderDao(), db.customerDao())
    val stockRepository = StockRepository(db.stockDao())
    val settingsPrefs = SettingsPrefs(context)
    val database = db
    val backupRepository = BackupRepository(db)

    // Compose-observable mirror of the persisted theme choice, so toggling
    // it in Settings recomposes the whole app immediately without a restart.
    val themeMode = mutableStateOf(settingsPrefs.themeMode)
}
