package com.shopmanager.app

import android.content.Context
import com.shopmanager.app.data.local.AppDatabase
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import com.shopmanager.app.data.repository.PaymentRepository

/**
 * Lightweight manual DI container. Keeps Phase 1 simple - no need to pull
 * in Hilt/Koin until the app grows (Phase 2+: Stock, Reports modules).
 */
class AppContainer(context: Context) {
    private val db = AppDatabase.getInstance(context)

    val customerRepository = CustomerRepository(db.customerDao())
    val orderRepository = OrderRepository(db.orderDao(), db.customerDao())
    val paymentRepository = PaymentRepository(db.paymentDao(), db.orderDao(), db.customerDao())
}
