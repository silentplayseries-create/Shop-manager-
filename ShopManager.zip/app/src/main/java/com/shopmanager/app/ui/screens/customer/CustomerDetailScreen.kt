package com.shopmanager.app.ui.screens.customer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.viewmodel.CustomerDetailViewModelFactory
import com.shopmanager.app.viewmodel.CustomerDetailViewModel
import com.shopmanager.app.viewmodel.TimelineEntry
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class DetailTab { DETAILS, HISTORY }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerDetailScreen(
    container: AppContainer,
    customerId: Long,
    onBack: () -> Unit
) {
    val viewModel: CustomerDetailViewModel = viewModel(
        factory = CustomerDetailViewModelFactory(
            customerId,
            container.customerRepository,
            container.orderRepository,
            container.paymentRepository
        )
    )
    val customer by viewModel.customer.collectAsState()
    val timeline by viewModel.timeline.collectAsState()
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    var selectedTab by remember { mutableStateOf(DetailTab.DETAILS) }
    var editDialogOpen by remember { mutableStateOf(false) }

    val currentCustomer = customer
    if (currentCustomer == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(currentCustomer.name) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { editDialogOpen = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            // Quick totals strip
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickTotal("Purchase", rupeeFormat.format(currentCustomer.totalPurchase), Modifier.weight(1f))
                QuickTotal("Paid", rupeeFormat.format(currentCustomer.totalPaid), Modifier.weight(1f))
                QuickTotal(
                    "Due", rupeeFormat.format(currentCustomer.totalDue), Modifier.weight(1f),
                    isAlert = currentCustomer.totalDue > 0
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            TabRow(selectedTabIndex = selectedTab.ordinal) {
                Tab(selected = selectedTab == DetailTab.DETAILS, onClick = { selectedTab = DetailTab.DETAILS }, text = { Text("Details") })
                Tab(selected = selectedTab == DetailTab.HISTORY, onClick = { selectedTab = DetailTab.HISTORY }, text = { Text("History") })
            }
            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                DetailTab.DETAILS -> DetailsTab(currentCustomer)
                DetailTab.HISTORY -> HistoryTab(timeline, rupeeFormat, dateFormat)
            }
        }
    }

    if (editDialogOpen) {
        EditCustomerDialog(
            name = currentCustomer.name,
            mobile = currentCustomer.mobile,
            address = currentCustomer.address,
            notes = currentCustomer.notes,
            onDismiss = { editDialogOpen = false },
            onSave = { name, mobile, address, notes ->
                viewModel.updateCustomer(name, mobile, address, notes)
                editDialogOpen = false
            }
        )
    }
}

@Composable
private fun QuickTotal(label: String, value: String, modifier: Modifier = Modifier, isAlert: Boolean = false) {
    Card(modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (isAlert) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DetailsTab(customer: com.shopmanager.app.data.local.entity.Customer) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoRow(Icons.Default.Call, "Mobile", customer.mobile)
        if (customer.address.isNotBlank()) InfoRow(Icons.Default.LocationOn, "Address", customer.address)
        if (customer.notes.isNotBlank()) InfoRow(Icons.Default.Notes, "Notes", customer.notes)
        Text(
            "Customer since ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(customer.createdAt))}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(label, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
private fun HistoryTab(
    timeline: List<TimelineEntry>,
    rupeeFormat: NumberFormat,
    dateFormat: SimpleDateFormat
) {
    if (timeline.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Abhi tak koi order ya payment nahi hai")
        }
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(timeline, key = {
            when (it) {
                is TimelineEntry.OrderEntry -> "o${it.order.id}"
                is TimelineEntry.PaymentEntry -> "p${it.payment.id}"
            }
        }) { entry ->
            when (entry) {
                is TimelineEntry.OrderEntry -> OrderTimelineRow(entry, rupeeFormat, dateFormat)
                is TimelineEntry.PaymentEntry -> PaymentTimelineRow(entry, rupeeFormat, dateFormat)
            }
        }
    }
}

@Composable
private fun OrderTimelineRow(entry: TimelineEntry.OrderEntry, rupeeFormat: NumberFormat, dateFormat: SimpleDateFormat) {
    val order = entry.order
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp)) {
            Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Order: ${order.furnitureName}", fontWeight = FontWeight.SemiBold)
                Text("Total: ${rupeeFormat.format(order.total)}  •  Balance: ${rupeeFormat.format(order.balance)}")
                Text(statusLabel(order.status), style = MaterialTheme.typography.bodySmall)
                Text(dateFormat.format(Date(order.createdAt)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

private fun statusLabel(status: OrderStatus): String = when (status) {
    OrderStatus.PENDING -> "Pending"
    OrderStatus.OUT_FOR_DELIVERY -> "Out for Delivery"
    OrderStatus.DELIVERED -> "Delivered"
    OrderStatus.CANCELLED -> "Cancelled"
}

@Composable
private fun PaymentTimelineRow(entry: TimelineEntry.PaymentEntry, rupeeFormat: NumberFormat, dateFormat: SimpleDateFormat) {
    val payment = entry.payment
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp)) {
            Icon(Icons.Default.Payments, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Payment Received: ${rupeeFormat.format(payment.amount)}", fontWeight = FontWeight.SemiBold)
                Text(payment.mode.name)
                if (payment.note.isNotBlank()) Text(payment.note, style = MaterialTheme.typography.bodySmall)
                Text(dateFormat.format(Date(payment.createdAt)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

@Composable
private fun EditCustomerDialog(
    name: String,
    mobile: String,
    address: String,
    notes: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var nameField by remember { mutableStateOf(name) }
    var mobileField by remember { mutableStateOf(mobile) }
    var addressField by remember { mutableStateOf(address) }
    var notesField by remember { mutableStateOf(notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Customer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nameField, onValueChange = { nameField = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(
                    value = mobileField,
                    onValueChange = { mobileField = it.filter { c -> c.isDigit() }.take(10) },
                    label = { Text("Mobile") },
                    singleLine = true
                )
                OutlinedTextField(value = addressField, onValueChange = { addressField = it }, label = { Text("Address") }, minLines = 2)
                OutlinedTextField(value = notesField, onValueChange = { notesField = it }, label = { Text("Notes") }, minLines = 2)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (nameField.isNotBlank() && mobileField.length == 10) {
                    onSave(nameField.trim(), mobileField, addressField.trim(), notesField.trim())
                }
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
