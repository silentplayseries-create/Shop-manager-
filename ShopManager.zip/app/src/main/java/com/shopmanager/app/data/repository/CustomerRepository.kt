package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.CustomerDao
import com.shopmanager.app.data.local.entity.Customer
import kotlinx.coroutines.flow.Flow

class CustomerRepository(private val customerDao: CustomerDao) {

    fun getAll(): Flow<List<Customer>> = customerDao.getAll()

    fun search(query: String): Flow<List<Customer>> =
        if (query.isBlank()) customerDao.getAll() else customerDao.search(query)

    fun getCustomerCount(): Flow<Int> = customerDao.getCustomerCount()

    suspend fun getById(id: Long): Customer? = customerDao.getById(id)

    suspend fun add(customer: Customer): Long = customerDao.insert(customer)

    suspend fun update(customer: Customer) = customerDao.update(customer)

    suspend fun delete(customer: Customer) = customerDao.delete(customer)
}
