package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.Payment
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import com.shopmanager.app.data.repository.PaymentRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class TimelineEntry {
    abstract val timestamp: Long
    data class OrderEntry(val order: Order) : TimelineEntry() {
        override val timestamp: Long get() = order.createdAt
    }
    data class PaymentEntry(val payment: Payment) : TimelineEntry() {
        override val timestamp: Long get() = payment.createdAt
    }
}

class CustomerDetailViewModel(
    private val customerId: Long,
    private val customerRepository: CustomerRepository,
    orderRepository: OrderRepository,
    paymentRepository: PaymentRepository
) : ViewModel() {

    private val _customer = MutableStateFlow<Customer?>(null)
    val customer: StateFlow<Customer?> = _customer.asStateFlow()

    val timeline: StateFlow<List<TimelineEntry>> = combine(
        orderRepository.getForCustomer(customerId),
        paymentRepository.getForCustomer(customerId)
    ) { orders, payments ->
        (orders.map { TimelineEntry.OrderEntry(it) } + payments.map { TimelineEntry.PaymentEntry(it) })
            .sortedByDescending { it.timestamp }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            _customer.value = customerRepository.getById(customerId)
        }
    }

    fun refreshCustomer() {
        viewModelScope.launch {
            _customer.value = customerRepository.getById(customerId)
        }
    }

    fun updateCustomer(name: String, mobile: String, address: String, notes: String) {
        val current = _customer.value ?: return
        viewModelScope.launch {
            val updated = current.copy(name = name, mobile = mobile, address = address, notes = notes)
            customerRepository.update(updated)
            _customer.value = updated
        }
    }
}

/**
 * Dedicated factory since CustomerDetailViewModel needs a customerId
 * constructor arg that the shared ViewModelFactory doesn't carry.
 */
class CustomerDetailViewModelFactory(
    private val customerId: Long,
    private val customerRepository: CustomerRepository,
    private val orderRepository: OrderRepository,
    private val paymentRepository: PaymentRepository
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        return CustomerDetailViewModel(customerId, customerRepository, orderRepository, paymentRepository) as T
    }
}
