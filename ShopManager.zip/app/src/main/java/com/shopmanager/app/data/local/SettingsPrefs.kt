package com.shopmanager.app.data.local

import android.content.Context

/**
 * Settings Module (Master Spec Section 17): Shop Name, Owner Name, and
 * (per user request) social media links. Plain SharedPreferences is enough
 * here - this is tiny key-value config, not data that needs Room/queries.
 */
class SettingsPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("shop_settings", Context.MODE_PRIVATE)

    var shopName: String
        get() = prefs.getString(KEY_SHOP_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SHOP_NAME, value).apply()

    var ownerName: String
        get() = prefs.getString(KEY_OWNER_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_OWNER_NAME, value).apply()

    var facebookUrl: String
        get() = prefs.getString(KEY_FACEBOOK, "") ?: ""
        set(value) = prefs.edit().putString(KEY_FACEBOOK, value).apply()

    var instagramUrl: String
        get() = prefs.getString(KEY_INSTAGRAM, "") ?: ""
        set(value) = prefs.edit().putString(KEY_INSTAGRAM, value).apply()

    // Section 18: Security - PIN Lock. Stored as plain text in app-private
    // SharedPreferences. This is basic screen-lock protection for a small
    // shop app, not encrypted/enterprise-grade security.
    var pinCode: String
        get() = prefs.getString(KEY_PIN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_PIN, value).apply()

    val isPinEnabled: Boolean get() = pinCode.isNotBlank()

    // Section 19: UI Theme - Dark Blue / White / Dark
    var themeMode: ThemeMode
        get() = ThemeMode.entries.find { it.name == prefs.getString(KEY_THEME_MODE, ThemeMode.DARK_BLUE.name) }
            ?: ThemeMode.DARK_BLUE
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value.name).apply()

    companion object {
        private const val KEY_SHOP_NAME = "shop_name"
        private const val KEY_OWNER_NAME = "owner_name"
        private const val KEY_FACEBOOK = "facebook_url"
        private const val KEY_INSTAGRAM = "instagram_url"
        private const val KEY_PIN = "pin_code"
        private const val KEY_THEME_MODE = "theme_mode"
    }
}

enum class ThemeMode { DARK_BLUE, WHITE, DARK }
