package com.shopmanager.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.shopmanager.app.ui.navigation.ShopManagerApp
import com.shopmanager.app.ui.screens.pin.PinLockScreen
import com.shopmanager.app.ui.theme.ShopManagerTheme
import com.shopmanager.app.util.BiometricAuthHelper
import com.shopmanager.app.util.ReminderWorker
import java.util.concurrent.TimeUnit

// AppCompatActivity (which extends FragmentActivity, so androidx.biometric's
// BiometricPrompt still works fine) is needed for per-app language switching
// (Section 4/17) via AppCompatDelegate.
class MainActivity : AppCompatActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appContainer = AppContainer(applicationContext)
        scheduleReminderWork()

        setContent {
            val themeMode by appContainer.themeMode
            var isUnlocked by remember {
                mutableStateOf(!appContainer.settingsPrefs.isPinEnabled)
            }
            val prefs = appContainer.settingsPrefs
            val canUseFingerprint = prefs.isPinEnabled && prefs.isFingerprintEnabled &&
                BiometricAuthHelper.canAuthenticate(this@MainActivity)

            // Android 13+ requires this permission to actually show a
            // notification; harmless to request even if reminders end up
            // disabled in Settings later.
            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { /* no-op either way - reminders just won't show if denied */ }

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            // Offer fingerprint immediately when the lock screen appears, so
            // the person doesn't have to tap an extra button every launch.
            LaunchedEffect(isUnlocked) {
                if (!isUnlocked && canUseFingerprint) {
                    BiometricAuthHelper.showPrompt(
                        activity = this@MainActivity,
                        onSuccess = { isUnlocked = true },
                        onError = { /* falls back to PIN field, already shown */ }
                    )
                }
            }

            ShopManagerTheme(mode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (isUnlocked) {
                        ShopManagerApp(container = appContainer)
                    } else {
                        PinLockScreen(
                            correctPin = prefs.pinCode,
                            onUnlocked = { isUnlocked = true },
                            onUseFingerprint = if (canUseFingerprint) {
                                {
                                    BiometricAuthHelper.showPrompt(
                                        activity = this@MainActivity,
                                        onSuccess = { isUnlocked = true },
                                        onError = { }
                                    )
                                }
                            } else null
                        )
                    }
                }
            }
        }
    }

    // Section 15: Notifications - checks pending payments / low stock once
    // a day. KEEP policy means re-launching the app doesn't create duplicate
    // scheduled jobs.
    private fun scheduleReminderWork() {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "shop_manager_daily_reminders",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
