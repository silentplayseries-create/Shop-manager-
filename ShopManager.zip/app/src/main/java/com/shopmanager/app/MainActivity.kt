package com.shopmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.shopmanager.app.ui.navigation.ShopManagerApp
import com.shopmanager.app.ui.screens.pin.PinLockScreen
import com.shopmanager.app.ui.theme.ShopManagerTheme

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appContainer = AppContainer(applicationContext)

        setContent {
            val isDarkBlue by appContainer.isDarkBlueTheme
            var isUnlocked by remember {
                mutableStateOf(!appContainer.settingsPrefs.isPinEnabled)
            }

            ShopManagerTheme(isDarkBlue = isDarkBlue) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (isUnlocked) {
                        ShopManagerApp(container = appContainer)
                    } else {
                        PinLockScreen(
                            correctPin = appContainer.settingsPrefs.pinCode,
                            onUnlocked = { isUnlocked = true }
                        )
                    }
                }
            }
        }
    }
}
