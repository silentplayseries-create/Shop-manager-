package com.shopmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.shopmanager.app.ui.navigation.ShopManagerApp
import com.shopmanager.app.ui.theme.ShopManagerTheme

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appContainer = AppContainer(applicationContext)

        setContent {
            ShopManagerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ShopManagerApp(container = appContainer)
                }
            }
        }
    }
}
