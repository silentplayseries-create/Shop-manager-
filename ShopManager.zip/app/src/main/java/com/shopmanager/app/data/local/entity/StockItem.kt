package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stock Module (Master Spec Section 10). imagePath points to a photo copied
 * into the app's private storage (via ImageStorageHelper), so it survives
 * even if the original gallery image is later deleted.
 */
@Entity(tableName = "stock_items")
data class StockItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val furnitureName: String,
    val category: String,
    val buyingPrice: Double,
    val sellingPrice: Double,
    val quantity: Int,
    val minQuantity: Int = 2,
    val supplier: String = "",
    val imagePath: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val isLowStock: Boolean get() = quantity <= minQuantity
}
