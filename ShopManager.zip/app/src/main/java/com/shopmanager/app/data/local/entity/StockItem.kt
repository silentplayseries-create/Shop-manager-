package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stock Module (Master Spec Section 10).
 */
@Entity(tableName = "stock_items")
data class StockItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val furnitureName: String,
    val category: String,
    val buyingPrice: Double,
    val sellingPrice: Double,
    val quantity: Int,
    val minQuantity: Int = 2,
    val supplier: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val isLowStock: Boolean get() = quantity <= minQuantity
}
