package com.shopmanager.app.ui.screens.voice

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.viewmodel.VoiceAssistantViewModel
import com.shopmanager.app.viewmodel.VoiceResult
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.util.Locale

@Composable
fun VoiceAssistantScreen(container: AppContainer) {
    val viewModel: VoiceAssistantViewModel = viewModel(factory = ViewModelFactory(container))
    val lastResult by viewModel.lastResult.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }
    var noRecognizerAvailable by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("hi-IN") }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val heard = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (heard != null) viewModel.processCommand(heard)
        }
    }

    fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolein...")
        }
        try {
            launcher.launch(intent)
        } catch (e: Exception) {
            noRecognizerAvailable = true
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Voice Assistant",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Abhi sirf ye commands samajhta hai: \"aaj ki sale batao\", \"<naam> ka account dikhao\". " +
                "Ye basic pattern-matching hai, poori tarah AI jaisa samajhdar nahi.",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = language == "hi-IN", onClick = { language = "hi-IN" }, label = { Text("Hindi") })
            FilterChip(selected = language == "en-IN", onClick = { language = "en-IN" }, label = { Text("English") })
        }
        Spacer(modifier = Modifier.height(32.dp))

        FloatingActionButton(
            onClick = {
                viewModel.clearResult()
                startListening()
            },
            modifier = Modifier.size(80.dp)
        ) {
            Icon(Icons.Default.Mic, contentDescription = "Start listening", modifier = Modifier.size(36.dp))
        }
        Spacer(modifier = Modifier.height(24.dp))

        if (noRecognizerAvailable) {
            Text(
                "Is phone me voice input available nahi hai. Google app installed hona chahiye.",
                color = MaterialTheme.colorScheme.error
            )
        }

        if (isProcessing) {
            CircularProgressIndicator()
        }

        lastResult?.let { result ->
            Spacer(modifier = Modifier.height(8.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    when (result) {
                        is VoiceResult.TodaySale -> {
                            Text("Aaj ki Sale", fontWeight = FontWeight.SemiBold)
                            Text(rupeeFormat.format(result.amount), style = MaterialTheme.typography.headlineSmall)
                        }
                        is VoiceResult.CustomerFound -> {
                            Text(result.customer.name, fontWeight = FontWeight.SemiBold)
                            Text("Mobile: ${result.customer.mobile}")
                            Text("Total Due: ${rupeeFormat.format(result.customer.totalDue)}")
                        }
                        is VoiceResult.CustomerNotFound -> {
                            Text("\"${result.searchedName}\" naam ka customer nahi mila", color = MaterialTheme.colorScheme.error)
                        }
                        is VoiceResult.Unrecognized -> {
                            Text("Suna: \"${result.heardText}\"")
                            Text(
                                "Ye command samajh nahi aayi. Upar diye gaye examples try karein.",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}
