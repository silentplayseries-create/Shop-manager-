package com.shopmanager.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.shopmanager.app.AppContainer
import com.shopmanager.app.ui.screens.customer.CustomerFormScreen
import com.shopmanager.app.ui.screens.customer.CustomerListScreen
import com.shopmanager.app.ui.screens.dashboard.DashboardScreen
import com.shopmanager.app.ui.screens.order.OrderFormScreen
import com.shopmanager.app.ui.screens.order.OrderListScreen

object Routes {
    const val DASHBOARD = "dashboard"
    const val CUSTOMERS = "customers"
    const val CUSTOMER_FORM = "customer_form"
    const val ORDERS = "orders"
    const val ORDER_FORM = "order_form"

    // Placeholders wired up in Phase 2 (Section: Development Roadmap)
    const val STOCK = "stock"
    const val REPORTS = "reports"
    const val CALCULATOR = "calculator"
    const val VOICE_ASSISTANT = "voice_assistant"
}

@Composable
fun ShopManagerNavHost(
    container: AppContainer,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {

        composable(Routes.DASHBOARD) {
            DashboardScreen(
                container = container,
                onNewOrder = { navController.navigate(Routes.ORDER_FORM) },
                onCustomers = { navController.navigate(Routes.CUSTOMERS) },
                onStock = { /* Phase 2 */ },
                onReports = { /* Phase 2 */ },
                onCalculator = { /* Phase 2 */ },
                onVoiceAssistant = { /* Phase 3 */ }
            )
        }

        composable(Routes.CUSTOMERS) {
            CustomerListScreen(
                container = container,
                onAddCustomer = { navController.navigate(Routes.CUSTOMER_FORM) },
                onCustomerClick = { /* Customer detail screen - Phase 1.1 */ }
            )
        }

        composable(Routes.CUSTOMER_FORM) {
            CustomerFormScreen(
                container = container,
                onSaved = { navController.popBackStack() }
            )
        }

        composable(Routes.ORDERS) {
            OrderListScreen(
                container = container,
                onNewOrder = { navController.navigate(Routes.ORDER_FORM) }
            )
        }

        composable(Routes.ORDER_FORM) {
            OrderFormScreen(
                container = container,
                onSaved = { navController.popBackStack() }
            )
        }
    }
}
