package com.shopmanager.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.shopmanager.app.AppContainer
import com.shopmanager.app.ui.screens.calculator.CalculatorScreen
import com.shopmanager.app.ui.screens.customer.CustomerFormScreen
import com.shopmanager.app.ui.screens.customer.CustomerListScreen
import com.shopmanager.app.ui.screens.dashboard.DashboardScreen
import com.shopmanager.app.ui.screens.order.OrderFormScreen
import com.shopmanager.app.ui.screens.order.OrderListScreen
import com.shopmanager.app.ui.screens.reports.ReportsScreen
import com.shopmanager.app.ui.screens.settings.SettingsScreen
import com.shopmanager.app.ui.screens.stock.StockFormScreen
import com.shopmanager.app.ui.screens.stock.StockListScreen
import com.shopmanager.app.ui.screens.voice.VoiceAssistantScreen

object Routes {
    const val DASHBOARD = "dashboard"
    const val CUSTOMERS = "customers"
    const val CUSTOMER_FORM = "customer_form"
    const val ORDERS = "orders"
    const val ORDER_FORM = "order_form"
    const val SETTINGS = "settings"
    const val STOCK = "stock"
    const val STOCK_FORM = "stock_form"
    const val REPORTS = "reports"
    const val CALCULATOR = "calculator"
    const val VOICE_ASSISTANT = "voice_assistant"
}

@Composable
fun ShopManagerNavHost(
    container: AppContainer,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {

        composable(Routes.DASHBOARD) {
            DashboardScreen(
                container = container,
                onNewOrder = { navController.navigate(Routes.ORDER_FORM) },
                onCustomers = { navController.navigate(Routes.CUSTOMERS) },
                onStock = { navController.navigate(Routes.STOCK) },
                onReports = { navController.navigate(Routes.REPORTS) },
                onCalculator = { navController.navigate(Routes.CALCULATOR) },
                onVoiceAssistant = { navController.navigate(Routes.VOICE_ASSISTANT) },
                onSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(container = container)
        }

        composable(Routes.CUSTOMERS) {
            CustomerListScreen(
                container = container,
                onAddCustomer = { navController.navigate(Routes.CUSTOMER_FORM) },
                onCustomerClick = { /* Customer detail screen - future improvement */ }
            )
        }

        composable(Routes.CUSTOMER_FORM) {
            CustomerFormScreen(
                container = container,
                onSaved = { navController.popBackStack() }
            )
        }

        composable(Routes.ORDERS) {
            OrderListScreen(
                container = container,
                onNewOrder = { navController.navigate(Routes.ORDER_FORM) }
            )
        }

        composable(Routes.ORDER_FORM) {
            OrderFormScreen(
                container = container,
                onSaved = { navController.popBackStack() }
            )
        }

        composable(Routes.STOCK) {
            StockListScreen(
                container = container,
                onAddItem = { navController.navigate(Routes.STOCK_FORM) },
                onItemClick = { /* Edit screen - future improvement, delete/add both work */ }
            )
        }

        composable(Routes.STOCK_FORM) {
            StockFormScreen(
                container = container,
                onSaved = { navController.popBackStack() }
            )
        }

        composable(Routes.REPORTS) {
            ReportsScreen(container = container)
        }

        composable(Routes.CALCULATOR) {
            CalculatorScreen()
        }

        composable(Routes.VOICE_ASSISTANT) {
            VoiceAssistantScreen(container = container)
        }
    }
}
