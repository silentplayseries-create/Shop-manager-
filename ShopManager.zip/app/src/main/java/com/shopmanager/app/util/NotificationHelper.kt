package com.shopmanager.app.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Section 15: Notifications - Pending Payment Reminder, Low Stock Reminder.
 * Uses a plain local notification (no push server needed, fits offline-first).
 */
object NotificationHelper {
    const val CHANNEL_ID = "shop_manager_reminders"
    private const val PENDING_PAYMENT_NOTIFICATION_ID = 1001
    private const val LOW_STOCK_NOTIFICATION_ID = 1002

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Shop Manager Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Pending payment aur low stock reminders"
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun showPendingPaymentReminder(context: Context, amountText: String, orderCount: Int) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pending Payments")
            .setContentText("$orderCount orders me total $amountText baki hai")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notifySafely(PENDING_PAYMENT_NOTIFICATION_ID, notification)
    }

    fun showLowStockReminder(context: Context, itemCount: Int) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Low Stock Alert")
            .setContentText("$itemCount items ka stock kam hai")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notifySafely(LOW_STOCK_NOTIFICATION_ID, notification)
    }

    // POST_NOTIFICATIONS can be denied on Android 13+; NotificationManagerCompat.notify
    // would throw SecurityException in that case, so this guards every call site.
    private fun NotificationManagerCompat.notifySafely(id: Int, notification: android.app.Notification) {
        try {
            notify(id, notification)
        } catch (e: SecurityException) {
            // Permission not granted - silently skip, nothing else to do here.
        }
    }
}
