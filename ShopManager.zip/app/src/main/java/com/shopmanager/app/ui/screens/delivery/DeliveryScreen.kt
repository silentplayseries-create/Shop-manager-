package com.shopmanager.app.ui.screens.delivery

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.viewmodel.DeliveryViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeliveryScreen(container: AppContainer) {
    val viewModel: DeliveryViewModel = viewModel(factory = ViewModelFactory(container))
    val orders by viewModel.orders.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val customerNameById = remember(customers) { customers.associate { it.id to it.name } }

    val pipelineOrders = remember(orders) {
        orders.filter { it.status == OrderStatus.PENDING || it.status == OrderStatus.OUT_FOR_DELIVERY }
            .sortedBy { it.deliveryDate ?: Long.MAX_VALUE }
    }
    val deliveredOrders = remember(orders) {
        orders.filter { it.status == OrderStatus.DELIVERED }.sortedByDescending { it.deliveryDate ?: it.createdAt }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Delivery", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        if (pipelineOrders.isEmpty() && deliveredOrders.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Koi delivery pending nahi hai")
            }
            return@Column
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (pipelineOrders.isNotEmpty()) {
                item {
                    Text("Pending / Out for Delivery (${pipelineOrders.size})", fontWeight = FontWeight.SemiBold)
                }
                items(pipelineOrders, key = { it.id }) { order ->
                    DeliveryRow(
                        order = order,
                        customerName = customerNameById[order.customerId] ?: "Customer",
                        dateFormat = dateFormat,
                        onMarkOutForDelivery = { viewModel.markOutForDelivery(order) },
                        onMarkDelivered = { viewModel.markDelivered(order) }
                    )
                }
            }
            if (deliveredOrders.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Delivered (${deliveredOrders.size})", fontWeight = FontWeight.SemiBold)
                }
                items(deliveredOrders.take(20), key = { "d_${it.id}" }) { order ->
                    DeliveryRow(
                        order = order,
                        customerName = customerNameById[order.customerId] ?: "Customer",
                        dateFormat = dateFormat,
                        onMarkOutForDelivery = {},
                        onMarkDelivered = {}
                    )
                }
            }
        }
    }
}

@Composable
private fun DeliveryRow(
    order: Order,
    customerName: String,
    dateFormat: SimpleDateFormat,
    onMarkOutForDelivery: () -> Unit,
    onMarkDelivered: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(order.furnitureName, fontWeight = FontWeight.SemiBold)
                    Text(customerName, style = MaterialTheme.typography.bodyMedium)
                }
                StatusChip(order.status)
            }
            order.deliveryDate?.let {
                Text("Delivery Date: ${dateFormat.format(Date(it))}", style = MaterialTheme.typography.bodyMedium)
            }
            if (order.status != OrderStatus.DELIVERED) {
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    if (order.status == OrderStatus.PENDING) {
                        TextButton(onClick = onMarkOutForDelivery) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Out for Delivery")
                        }
                    }
                    TextButton(onClick = onMarkDelivered) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delivered")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusChip(status: OrderStatus) {
    val (label, color) = when (status) {
        OrderStatus.PENDING -> "Pending" to MaterialTheme.colorScheme.tertiary
        OrderStatus.OUT_FOR_DELIVERY -> "Out for Delivery" to MaterialTheme.colorScheme.primary
        OrderStatus.DELIVERED -> "Delivered" to MaterialTheme.colorScheme.primary
        OrderStatus.CANCELLED -> "Cancelled" to MaterialTheme.colorScheme.error
    }
    AssistChip(onClick = {}, label = { Text(label) }, colors = AssistChipDefaults.assistChipColors(labelColor = color))
}
