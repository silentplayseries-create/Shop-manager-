package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Attendance
import com.shopmanager.app.data.local.entity.AttendanceStatus
import com.shopmanager.app.data.local.entity.Staff
import com.shopmanager.app.data.repository.StaffRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StaffViewModel(private val repository: StaffRepository) : ViewModel() {

    val staffList: StateFlow<List<Staff>> = repository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayAttendance: StateFlow<List<Attendance>> = repository.getAttendanceForDay(repository.todayKey())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addStaff(name: String, mobile: String, role: String, monthlySalary: Double, notes: String) {
        viewModelScope.launch {
            repository.add(Staff(name = name, mobile = mobile, role = role, monthlySalary = monthlySalary, notes = notes))
        }
    }

    fun deleteStaff(staff: Staff) {
        viewModelScope.launch { repository.delete(staff) }
    }

    fun markAttendance(staffId: Long, status: AttendanceStatus) {
        viewModelScope.launch { repository.markAttendance(staffId, status) }
    }
}
