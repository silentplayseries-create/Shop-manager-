package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Payment
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.PaymentRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PaymentViewModel(
    private val paymentRepository: PaymentRepository,
    customerRepository: CustomerRepository
) : ViewModel() {

    val payments: StateFlow<List<Payment>> = paymentRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val monthTotal: StateFlow<Double> = paymentRepository.getThisMonthTotal()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val customers = customerRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun receivePayment(customerId: Long, amount: Double, mode: PaymentMode, note: String) {
        viewModelScope.launch {
            paymentRepository.recordPayment(
                Payment(customerId = customerId, orderId = null, amount = amount, mode = mode, note = note)
            )
        }
    }
}
