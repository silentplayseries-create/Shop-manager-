package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.CustomerDao
import com.shopmanager.app.data.local.dao.OrderDao
import com.shopmanager.app.data.local.entity.Order
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class OrderRepository(
    private val orderDao: OrderDao,
    private val customerDao: CustomerDao
) {

    fun getAll(): Flow<List<Order>> = orderDao.getAll()

    fun getForCustomer(customerId: Long): Flow<List<Order>> = orderDao.getForCustomer(customerId)

    suspend fun getById(id: Long): Order? = orderDao.getById(id)

    /** Creates the order and bumps the customer's running totals in one step. */
    suspend fun addOrder(order: Order): Long {
        val id = orderDao.insert(order)
        customerDao.applyTotalsDelta(
            customerId = order.customerId,
            purchaseDelta = order.total,
            paidDelta = order.advance,
            dueDelta = order.balance
        )
        return id
    }

    /**
     * Replaces an existing order, correcting the customer's totals by the
     * *difference* between old and new values rather than re-summing everything.
     */
    suspend fun updateOrder(oldOrder: Order, newOrder: Order) {
        orderDao.update(newOrder)
        customerDao.applyTotalsDelta(
            customerId = newOrder.customerId,
            purchaseDelta = newOrder.total - oldOrder.total,
            paidDelta = newOrder.advance - oldOrder.advance,
            dueDelta = newOrder.balance - oldOrder.balance
        )
    }

    suspend fun deleteOrder(order: Order) {
        orderDao.delete(order)
        customerDao.applyTotalsDelta(
            customerId = order.customerId,
            purchaseDelta = -order.total,
            paidDelta = -order.advance,
            dueDelta = -order.balance
        )
    }

    // --- Dashboard (Section 6) ---

    fun getTodaySaleTotal(): Flow<Double> {
        val (start, end) = todayRange()
        return orderDao.getTodaySaleTotal(start, end)
    }

    fun getTodayOrderCount(): Flow<Int> {
        val (start, end) = todayRange()
        return orderDao.getTodayOrderCount(start, end)
    }

    fun getPendingDeliveryCount(): Flow<Int> = orderDao.getPendingDeliveryCount()

    fun getTotalPendingPayments(): Flow<Double> = orderDao.getTotalPendingPayments()

    fun getOrdersWithPendingBalance(): Flow<List<Order>> = orderDao.getOrdersWithPendingBalance()

    private fun todayRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_MONTH, 1)
        val end = cal.timeInMillis - 1
        return start to end
    }
}
