package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.data.repository.OrderRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class OrderViewModel(private val repository: OrderRepository) : ViewModel() {

    val orders: StateFlow<List<Order>> = repository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addOrder(
        customerId: Long,
        furnitureName: String,
        category: String,
        quantity: Int,
        price: Double,
        discount: Double,
        gstPercent: Double,
        advance: Double,
        deliveryDate: Long?,
        paymentMode: PaymentMode,
        notes: String
    ) {
        viewModelScope.launch {
            val total = Order.calculateTotal(quantity, price, discount, gstPercent)
            val balance = (total - advance).coerceAtLeast(0.0)
            repository.addOrder(
                Order(
                    customerId = customerId,
                    furnitureName = furnitureName,
                    category = category,
                    quantity = quantity,
                    price = price,
                    discount = discount,
                    gstPercent = gstPercent,
                    total = total,
                    advance = advance,
                    balance = balance,
                    deliveryDate = deliveryDate,
                    paymentMode = paymentMode,
                    notes = notes,
                    status = OrderStatus.PENDING
                )
            )
        }
    }

    fun markDelivered(order: Order) {
        viewModelScope.launch {
            repository.updateOrder(order, order.copy(status = OrderStatus.DELIVERED))
        }
    }

    fun deleteOrder(order: Order) {
        viewModelScope.launch { repository.deleteOrder(order) }
    }
}
