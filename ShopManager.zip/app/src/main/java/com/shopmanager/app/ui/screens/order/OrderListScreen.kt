package com.shopmanager.app.ui.screens.order

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.viewmodel.OrderViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrderListScreen(
    container: AppContainer,
    onNewOrder: () -> Unit
) {
    val viewModel: OrderViewModel = viewModel(factory = ViewModelFactory(container))
    val orders by viewModel.orders.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onNewOrder) {
                Icon(Icons.Default.Add, contentDescription = "New Order")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Orders",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (orders.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Abhi tak koi order nahi", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(orders, key = { it.id }) { order ->
                        OrderRow(
                            order = order,
                            rupeeFormat = rupeeFormat,
                            dateFormat = dateFormat,
                            onMarkDelivered = { viewModel.markDelivered(order) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OrderRow(
    order: Order,
    rupeeFormat: NumberFormat,
    dateFormat: SimpleDateFormat,
    onMarkDelivered: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${order.furnitureName} (${order.category})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                StatusBadge(order.status)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text("Qty: ${order.quantity}  •  Total: ${rupeeFormat.format(order.total)}")
            Text("Advance: ${rupeeFormat.format(order.advance)}  •  Balance: ${rupeeFormat.format(order.balance)}")
            order.deliveryDate?.let {
                Text("Delivery: ${dateFormat.format(Date(it))}", style = MaterialTheme.typography.bodyMedium)
            }

            if (order.status == OrderStatus.PENDING) {
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onMarkDelivered) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mark Delivered")
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: OrderStatus) {
    val (label, color) = when (status) {
        OrderStatus.PENDING -> "Pending" to MaterialTheme.colorScheme.tertiary
        OrderStatus.DELIVERED -> "Delivered" to MaterialTheme.colorScheme.primary
        OrderStatus.CANCELLED -> "Cancelled" to MaterialTheme.colorScheme.error
    }
    AssistChip(onClick = {}, label = { Text(label) }, colors = AssistChipDefaults.assistChipColors(labelColor = color))
}
