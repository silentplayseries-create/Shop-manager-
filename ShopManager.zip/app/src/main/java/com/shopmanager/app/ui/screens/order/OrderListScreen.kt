package com.shopmanager.app.ui.screens.order

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.util.InvoicePdfGenerator
import com.shopmanager.app.viewmodel.CustomerViewModel
import com.shopmanager.app.viewmodel.OrderViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrderListScreen(
    container: AppContainer,
    onNewOrder: () -> Unit
) {
    val viewModel: OrderViewModel = viewModel(factory = ViewModelFactory(container))
    val customerViewModel: CustomerViewModel = viewModel(factory = ViewModelFactory(container))
    val orders by viewModel.orders.collectAsState()
    val customers by customerViewModel.customers.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val context = LocalContext.current
    val settings = container.settingsPrefs

    // Quick lookup so each order row can show/share the customer's details
    // without a separate DB query per row.
    val customerById = remember(customers) { customers.associateBy { it.id } }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onNewOrder) {
                Icon(Icons.Default.Add, contentDescription = "New Order")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Orders",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (orders.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Abhi tak koi order nahi", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(orders, key = { it.id }) { order ->
                        val customer = customerById[order.customerId]
                        OrderRow(
                            order = order,
                            customerName = customer?.name ?: "Customer",
                            rupeeFormat = rupeeFormat,
                            dateFormat = dateFormat,
                            onMarkDelivered = { viewModel.markDelivered(order) },
                            onShare = {
                                val text = buildInvoiceText(
                                    shopName = settings.shopName,
                                    customerName = customer?.name ?: "Customer",
                                    order = order,
                                    rupeeFormat = rupeeFormat,
                                    dateFormat = dateFormat
                                )
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, text)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Invoice share karein"))
                            },
                            onSharePdf = {
                                val uri = InvoicePdfGenerator.generate(
                                    context = context,
                                    shopName = settings.shopName,
                                    ownerName = settings.ownerName,
                                    customerName = customer?.name ?: "Customer",
                                    customerMobile = customer?.mobile ?: "",
                                    order = order
                                )
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "PDF Invoice share karein"))
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Basic text invoice for sharing via WhatsApp/SMS/etc. See InvoicePdfGenerator
 * for the PDF version.
 */
private fun buildInvoiceText(
    shopName: String,
    customerName: String,
    order: Order,
    rupeeFormat: NumberFormat,
    dateFormat: SimpleDateFormat
): String = buildString {
    if (shopName.isNotBlank()) appendLine(shopName)
    appendLine("Customer: $customerName")
    appendLine("Item: ${order.furnitureName} (${order.category})")
    appendLine("Qty: ${order.quantity} x ${rupeeFormat.format(order.price)}")
    if (order.discount > 0) appendLine("Discount: ${rupeeFormat.format(order.discount)}")
    if (order.gstPercent > 0) appendLine("GST: ${order.gstPercent}%")
    appendLine("Total: ${rupeeFormat.format(order.total)}")
    appendLine("Advance Paid: ${rupeeFormat.format(order.advance)}")
    appendLine("Balance Due: ${rupeeFormat.format(order.balance)}")
    order.deliveryDate?.let { appendLine("Delivery Date: ${dateFormat.format(Date(it))}") }
}

@Composable
private fun OrderRow(
    order: Order,
    customerName: String,
    rupeeFormat: NumberFormat,
    dateFormat: SimpleDateFormat,
    onMarkDelivered: () -> Unit,
    onShare: () -> Unit,
    onSharePdf: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${order.furnitureName} (${order.category})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(customerName, style = MaterialTheme.typography.bodyMedium)
                }
                StatusBadge(order.status)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text("Qty: ${order.quantity}  •  Total: ${rupeeFormat.format(order.total)}")
            Text("Advance: ${rupeeFormat.format(order.advance)}  •  Balance: ${rupeeFormat.format(order.balance)}")
            order.deliveryDate?.let {
                Text("Delivery: ${dateFormat.format(Date(it))}", style = MaterialTheme.typography.bodyMedium)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (order.status == OrderStatus.PENDING) {
                    TextButton(onClick = onMarkDelivered) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Delivered")
                    }
                }
                Spacer(modifier = Modifier.weight(1f))
                TextButton(onClick = onSharePdf) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PDF")
                }
                TextButton(onClick = onShare) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: OrderStatus) {
    val (label, color) = when (status) {
        OrderStatus.PENDING -> "Pending" to MaterialTheme.colorScheme.tertiary
        OrderStatus.OUT_FOR_DELIVERY -> "Out for Delivery" to MaterialTheme.colorScheme.primary
        OrderStatus.DELIVERED -> "Delivered" to MaterialTheme.colorScheme.primary
        OrderStatus.CANCELLED -> "Cancelled" to MaterialTheme.colorScheme.error
    }
    AssistChip(onClick = {}, label = { Text(label) }, colors = AssistChipDefaults.assistChipColors(labelColor = color))
}
