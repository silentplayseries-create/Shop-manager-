package com.shopmanager.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.shopmanager.app.data.local.dao.AttendanceDao
import com.shopmanager.app.data.local.dao.CustomerDao
import com.shopmanager.app.data.local.dao.ExpenseDao
import com.shopmanager.app.data.local.dao.OrderDao
import com.shopmanager.app.data.local.dao.PaymentDao
import com.shopmanager.app.data.local.dao.StaffDao
import com.shopmanager.app.data.local.dao.StockDao
import com.shopmanager.app.data.local.dao.SupplierDao
import com.shopmanager.app.data.local.entity.Attendance
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Expense
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.Payment
import com.shopmanager.app.data.local.entity.Staff
import com.shopmanager.app.data.local.entity.StockItem
import com.shopmanager.app.data.local.entity.Supplier

/**
 * Single offline SQLite database (via Room) for the whole app.
 * This is the "Future Version" database from the master spec (Section 5)
 * used from day one, so there is no TinyDB -> SQLite migration later.
 */
@Database(
    entities = [
        Customer::class, Order::class, Payment::class, StockItem::class,
        Expense::class, Supplier::class, Staff::class, Attendance::class
    ],
    version = 3,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun customerDao(): CustomerDao
    abstract fun orderDao(): OrderDao
    abstract fun paymentDao(): PaymentDao
    abstract fun stockDao(): StockDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun supplierDao(): SupplierDao
    abstract fun staffDao(): StaffDao
    abstract fun attendanceDao(): AttendanceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shop_manager.db"
                )
                    // This app is still in active development with no real
                    // production data to preserve across schema changes, so
                    // a destructive migration is simpler and safer than
                    // hand-writing Migrations for every version bump.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
