package com.shopmanager.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.shopmanager.app.data.local.dao.CustomerDao
import com.shopmanager.app.data.local.dao.OrderDao
import com.shopmanager.app.data.local.dao.PaymentDao
import com.shopmanager.app.data.local.dao.StockDao
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.Payment
import com.shopmanager.app.data.local.entity.StockItem

/**
 * Single offline SQLite database (via Room) for the whole app.
 * This is the "Future Version" database from the master spec (Section 5)
 * used from day one, so there is no TinyDB -> SQLite migration later.
 */
@Database(
    entities = [Customer::class, Order::class, Payment::class, StockItem::class],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun customerDao(): CustomerDao
    abstract fun orderDao(): OrderDao
    abstract fun paymentDao(): PaymentDao
    abstract fun stockDao(): StockDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shop_manager.db"
                )
                    // No paying customers/data exist yet on any device running
                    // Phase 1, so a destructive migration is safe and far
                    // simpler than writing a real Migration for this jump.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
