package com.shopmanager.app.ui.screens.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.viewmodel.GlobalSearchViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.util.Locale

@Composable
fun GlobalSearchScreen(container: AppContainer) {
    val viewModel: GlobalSearchViewModel = viewModel(factory = ViewModelFactory(container))
    val query by viewModel.query.collectAsState()
    val results by viewModel.results.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Search", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = query,
            onValueChange = viewModel::onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Customer, order, stock, supplier...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))

        when {
            query.isBlank() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Kuch bhi search karna shuru karein", style = MaterialTheme.typography.bodyLarge)
                }
            }
            results.isEmpty -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Kuch nahi mila", style = MaterialTheme.typography.bodyLarge)
                }
            }
            else -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (results.customers.isNotEmpty()) {
                        item { SectionHeader("Customers") }
                        items(results.customers, key = { "c${it.id}" }) { customer ->
                            ResultRow(title = customer.name, subtitle = customer.mobile)
                        }
                    }
                    if (results.orders.isNotEmpty()) {
                        item { SectionHeader("Orders") }
                        items(results.orders, key = { "o${it.id}" }) { order ->
                            ResultRow(
                                title = "${order.furnitureName} (${order.category})",
                                subtitle = "Total: ${rupeeFormat.format(order.total)}  •  Balance: ${rupeeFormat.format(order.balance)}"
                            )
                        }
                    }
                    if (results.stockItems.isNotEmpty()) {
                        item { SectionHeader("Stock") }
                        items(results.stockItems, key = { "s${it.id}" }) { item ->
                            ResultRow(
                                title = "${item.furnitureName} (${item.category})",
                                subtitle = "Qty: ${item.quantity}  •  ${rupeeFormat.format(item.sellingPrice)}"
                            )
                        }
                    }
                    if (results.suppliers.isNotEmpty()) {
                        item { SectionHeader("Suppliers") }
                        items(results.suppliers, key = { "sup${it.id}" }) { supplier ->
                            ResultRow(title = supplier.name, subtitle = supplier.mobile)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(vertical = 6.dp)
    )
}

@Composable
private fun ResultRow(title: String, subtitle: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
