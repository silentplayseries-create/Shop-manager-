package com.shopmanager.app.data.local.dao

import androidx.room.*
import com.shopmanager.app.data.local.entity.Customer
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {

    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAll(): Flow<List<Customer>>

    @Query("""
        SELECT * FROM customers
        WHERE name LIKE '%' || :query || '%' OR mobile LIKE '%' || :query || '%'
        ORDER BY name ASC
    """)
    fun search(query: String): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getById(id: Long): Customer?

    @Query("SELECT COUNT(*) FROM customers")
    fun getCustomerCount(): Flow<Int>

    @Insert
    suspend fun insert(customer: Customer): Long

    @Update
    suspend fun update(customer: Customer)

    @Delete
    suspend fun delete(customer: Customer)

    // --- Backup/Restore (Section 16) ---

    @Query("SELECT * FROM customers")
    suspend fun getAllOnce(): List<Customer>

    @Query("DELETE FROM customers")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(customers: List<Customer>)

    // Called after an order/payment changes so the customer's running
    // totals (Section 7: Total Purchase / Total Paid / Total Due) stay in sync.
    @Query("""
        UPDATE customers SET
            totalPurchase = totalPurchase + :purchaseDelta,
            totalPaid = totalPaid + :paidDelta,
            totalDue = totalDue + :dueDelta
        WHERE id = :customerId
    """)
    suspend fun applyTotalsDelta(customerId: Long, purchaseDelta: Double, paidDelta: Double, dueDelta: Double)
}
