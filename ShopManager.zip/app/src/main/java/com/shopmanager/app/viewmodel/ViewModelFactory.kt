package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.shopmanager.app.AppContainer

class ViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when (modelClass) {
            DashboardViewModel::class.java ->
                DashboardViewModel(container.orderRepository, container.customerRepository, container.stockRepository) as T
            CustomerViewModel::class.java ->
                CustomerViewModel(container.customerRepository) as T
            OrderViewModel::class.java ->
                OrderViewModel(container.orderRepository) as T
            StockViewModel::class.java ->
                StockViewModel(container.stockRepository) as T
            ReportsViewModel::class.java ->
                ReportsViewModel(container.orderRepository, container.customerRepository, container.stockRepository) as T
            VoiceAssistantViewModel::class.java ->
                VoiceAssistantViewModel(container.orderRepository, container.customerRepository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
