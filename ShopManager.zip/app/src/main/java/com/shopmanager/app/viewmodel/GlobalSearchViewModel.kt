package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.StockItem
import com.shopmanager.app.data.local.entity.Supplier
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import com.shopmanager.app.data.repository.StockRepository
import com.shopmanager.app.data.repository.SupplierRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class GlobalSearchResults(
    val customers: List<Customer> = emptyList(),
    val orders: List<Order> = emptyList(),
    val stockItems: List<StockItem> = emptyList(),
    val suppliers: List<Supplier> = emptyList()
) {
    val isEmpty: Boolean get() = customers.isEmpty() && orders.isEmpty() && stockItems.isEmpty() && suppliers.isEmpty()
}

/**
 * Global Search - one bar to search customers, orders (by furniture name),
 * stock, and suppliers. Kept read-only (no deep-link into detail screens
 * that don't exist yet, like a per-customer profile) so results just show
 * key info inline.
 */
class GlobalSearchViewModel(
    private val customerRepository: CustomerRepository,
    private val orderRepository: OrderRepository,
    private val stockRepository: StockRepository,
    private val supplierRepository: SupplierRepository
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _results = MutableStateFlow(GlobalSearchResults())
    val results: StateFlow<GlobalSearchResults> = _results.asStateFlow()

    fun onQueryChange(newQuery: String) {
        _query.value = newQuery
        if (newQuery.isBlank()) {
            _results.value = GlobalSearchResults()
            return
        }
        viewModelScope.launch {
            val lower = newQuery.trim()
            val customers = customerRepository.search(lower).first()
            val allOrders = orderRepository.getAll().first()
            val matchedOrders = allOrders.filter {
                it.furnitureName.contains(lower, ignoreCase = true) || it.category.contains(lower, ignoreCase = true)
            }
            val stockItems = stockRepository.search(lower).first()
            val allSuppliers = supplierRepository.getAll().first()
            val matchedSuppliers = allSuppliers.filter {
                it.name.contains(lower, ignoreCase = true) || it.mobile.contains(lower, ignoreCase = true)
            }
            // Guard against a stale/slower search overwriting a newer one's results
            if (_query.value == newQuery) {
                _results.value = GlobalSearchResults(customers, matchedOrders, stockItems, matchedSuppliers)
            }
        }
    }
}
