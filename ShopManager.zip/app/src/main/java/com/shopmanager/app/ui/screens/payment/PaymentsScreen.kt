package com.shopmanager.app.ui.screens.payment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Payment
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.viewmodel.PaymentViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PaymentsScreen(container: AppContainer) {
    val viewModel: PaymentViewModel = viewModel(factory = ViewModelFactory(container))
    val payments by viewModel.payments.collectAsState()
    val monthTotal by viewModel.monthTotal.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }
    val dateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    var showReceiveDialog by remember { mutableStateOf(false) }

    val customerNameById = remember(customers) { customers.associate { it.id to it.name } }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showReceiveDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Receive Payment")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Payments", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Total Received (This Month)", style = MaterialTheme.typography.titleMedium)
                    Text(rupeeFormat.format(monthTotal), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            Text("Recent Payments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(8.dp))

            if (payments.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Koi payment nahi hai")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(payments, key = { it.id }) { payment ->
                        PaymentRow(payment, customerNameById[payment.customerId] ?: "Customer", rupeeFormat, dateFormat)
                    }
                }
            }
        }
    }

    if (showReceiveDialog) {
        ReceivePaymentDialog(
            customers = customers.map { it.id to it.name },
            onDismiss = { showReceiveDialog = false },
            onSave = { customerId, amount, mode, note ->
                viewModel.receivePayment(customerId, amount, mode, note)
                showReceiveDialog = false
            }
        )
    }
}

@Composable
private fun PaymentRow(payment: Payment, customerName: String, rupeeFormat: NumberFormat, dateFormat: SimpleDateFormat) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(customerName, fontWeight = FontWeight.SemiBold)
                Text("${payment.mode.name} • ${dateFormat.format(Date(payment.createdAt))}", style = MaterialTheme.typography.bodySmall)
            }
            Text(rupeeFormat.format(payment.amount), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReceivePaymentDialog(
    customers: List<Pair<Long, String>>,
    onDismiss: () -> Unit,
    onSave: (Long, Double, PaymentMode, String) -> Unit
) {
    var selectedCustomerId by remember { mutableStateOf<Long?>(null) }
    var customerDropdownExpanded by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(PaymentMode.CASH) }
    var modeDropdownExpanded by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val selectedCustomerName = customers.find { it.first == selectedCustomerId }?.second ?: ""

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receive Payment") },
        text = {
            Column {
                ExposedDropdownMenuBox(expanded = customerDropdownExpanded, onExpandedChange = { customerDropdownExpanded = it }) {
                    OutlinedTextField(
                        value = selectedCustomerName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Customer") },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = customerDropdownExpanded, onDismissRequest = { customerDropdownExpanded = false }) {
                        customers.forEach { (id, name) ->
                            DropdownMenuItem(text = { Text(name) }, onClick = {
                                selectedCustomerId = id
                                customerDropdownExpanded = false
                            })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Amount") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                ExposedDropdownMenuBox(expanded = modeDropdownExpanded, onExpandedChange = { modeDropdownExpanded = it }) {
                    OutlinedTextField(
                        value = mode.name,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Payment Mode") },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = modeDropdownExpanded, onDismissRequest = { modeDropdownExpanded = false }) {
                        PaymentMode.values().forEach { m ->
                            DropdownMenuItem(text = { Text(m.name) }, onClick = {
                                mode = m
                                modeDropdownExpanded = false
                            })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth())
                error?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amount = amountText.toDoubleOrNull()
                when {
                    selectedCustomerId == null -> error = "Customer select karein"
                    amount == null || amount <= 0 -> error = "Valid amount daalein"
                    else -> onSave(selectedCustomerId!!, amount, mode, note.trim())
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
