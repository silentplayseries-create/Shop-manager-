package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Voice Assistant (Master Spec Section 13) - IMPORTANT SCOPE NOTE:
 * This is basic regex/keyword pattern-matching against the transcribed
 * text, not true natural-language understanding. It recognizes a small,
 * fixed set of phrasings. Free-form conversational commands will not work
 * reliably - that would require a proper NLU/LLM pipeline, which conflicts
 * with the app's offline-first requirement (Section 2) unless a paid
 * always-online AI API is wired in separately.
 */
sealed class VoiceResult {
    data class TodaySale(val amount: Double) : VoiceResult()
    data class CustomerFound(val customer: Customer) : VoiceResult()
    data class CustomerNotFound(val searchedName: String) : VoiceResult()
    data class Unrecognized(val heardText: String) : VoiceResult()
}

class VoiceAssistantViewModel(
    private val orderRepository: OrderRepository,
    private val customerRepository: CustomerRepository
) : ViewModel() {

    private val _lastResult = MutableStateFlow<VoiceResult?>(null)
    val lastResult: StateFlow<VoiceResult?> = _lastResult.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun processCommand(heardText: String) {
        viewModelScope.launch {
            _isProcessing.value = true
            val text = heardText.trim().lowercase()

            val accountMatch = Regex("(.+?)\\s+ka\\s+account").find(text)
                ?: Regex("(.+?)\\s+ki\\s+details").find(text)

            _lastResult.value = when {
                text.contains("aaj ki sale") || text.contains("today's sale") || text.contains("today sale") -> {
                    val total = orderRepository.getTodaySaleTotal().first()
                    VoiceResult.TodaySale(total)
                }
                accountMatch != null -> {
                    val name = accountMatch.groupValues[1].trim()
                    val found = customerRepository.search(name).first().firstOrNull()
                    if (found != null) VoiceResult.CustomerFound(found) else VoiceResult.CustomerNotFound(name)
                }
                else -> VoiceResult.Unrecognized(heardText)
            }
            _isProcessing.value = false
        }
    }

    fun clearResult() {
        _lastResult.value = null
    }
}
