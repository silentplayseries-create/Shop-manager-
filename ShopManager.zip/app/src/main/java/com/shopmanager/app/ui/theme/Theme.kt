package com.shopmanager.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkBlueColorScheme = lightColorScheme(
    primary = ShopBlue,
    onPrimary = ShopSurface,
    primaryContainer = ShopBlueLight,
    secondary = ShopBlueDark,
    background = ShopBackground,
    surface = ShopSurface,
    error = ShopError,
    onBackground = ShopTextPrimary,
    onSurface = ShopTextPrimary
)

// Section 19: alternate "White" theme option
private val WhiteColorScheme = lightColorScheme(
    primary = Color(0xFF37474F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFECEFF1),
    secondary = Color(0xFF546E7A),
    background = Color.White,
    surface = Color.White,
    error = ShopError,
    onBackground = Color(0xFF1A1C1E),
    onSurface = Color(0xFF1A1C1E)
)

// Section 19: Rounded Buttons
private val ShopShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ShopManagerTheme(isDarkBlue: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isDarkBlue) DarkBlueColorScheme else WhiteColorScheme,
        typography = ShopTypography,
        shapes = ShopShapes,
        content = content
    )
}
