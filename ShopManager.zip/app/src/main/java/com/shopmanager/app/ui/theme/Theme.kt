package com.shopmanager.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ShopColorScheme = lightColorScheme(
    primary = ShopBlue,
    onPrimary = ShopSurface,
    primaryContainer = ShopBlueLight,
    secondary = ShopBlueDark,
    background = ShopBackground,
    surface = ShopSurface,
    error = ShopError,
    onBackground = ShopTextPrimary,
    onSurface = ShopTextPrimary
)

// Section 19: Rounded Buttons
private val ShopShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ShopManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ShopColorScheme,
        typography = ShopTypography,
        shapes = ShopShapes,
        content = content
    )
}
