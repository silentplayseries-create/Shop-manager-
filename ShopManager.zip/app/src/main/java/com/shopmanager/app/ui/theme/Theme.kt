package com.shopmanager.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.shopmanager.app.data.local.ThemeMode

private val DarkBlueColorScheme = lightColorScheme(
    primary = ShopBlue,
    onPrimary = ShopSurface,
    primaryContainer = ShopBlueLight,
    secondary = ShopBlueDark,
    background = ShopBackground,
    surface = ShopSurface,
    error = ShopError,
    onBackground = ShopTextPrimary,
    onSurface = ShopTextPrimary
)

private val WhiteColorScheme = lightColorScheme(
    primary = Color(0xFF37474F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFECEFF1),
    secondary = Color(0xFF546E7A),
    background = Color.White,
    surface = Color.White,
    error = ShopError,
    onBackground = Color(0xFF1A1C1E),
    onSurface = Color(0xFF1A1C1E)
)

// True dark theme: near-black background with a light-blue accent, matching
// the reference "FurniStore Business Manager" mockup's card-on-dark style.
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF5B9DFF),
    onPrimary = Color(0xFF0A0E14),
    primaryContainer = Color(0xFF1E2530),
    secondary = Color(0xFF4CAF7D),
    background = Color(0xFF0F1115),
    surface = Color(0xFF171A21),
    surfaceVariant = Color(0xFF1E2530),
    error = Color(0xFFEF5350),
    onBackground = Color(0xFFECEFF4),
    onSurface = Color(0xFFECEFF4)
)

// Section 19: Rounded Buttons
private val ShopShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ShopManagerTheme(mode: ThemeMode = ThemeMode.DARK_BLUE, content: @Composable () -> Unit) {
    val colorScheme = when (mode) {
        ThemeMode.DARK_BLUE -> DarkBlueColorScheme
        ThemeMode.WHITE -> WhiteColorScheme
        ThemeMode.DARK -> DarkColorScheme
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = ShopTypography,
        shapes = ShopShapes,
        content = content
    )
}
