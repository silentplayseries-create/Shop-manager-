package com.shopmanager.app.ui.screens.stock

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.viewmodel.StockViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory

@Composable
fun StockFormScreen(
    container: AppContainer,
    onSaved: () -> Unit
) {
    val viewModel: StockViewModel = viewModel(factory = ViewModelFactory(container))

    var furnitureName by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var buyingPriceText by remember { mutableStateOf("") }
    var sellingPriceText by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("") }
    var minQuantityText by remember { mutableStateOf("2") }
    var supplier by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("New Stock Item", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = furnitureName,
            onValueChange = { furnitureName = it },
            label = { Text("Furniture Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = buyingPriceText,
                onValueChange = { buyingPriceText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Buying Price") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                value = sellingPriceText,
                onValueChange = { sellingPriceText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Selling Price") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = quantityText,
                onValueChange = { quantityText = it.filter { c -> c.isDigit() } },
                label = { Text("Quantity") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = minQuantityText,
                onValueChange = { minQuantityText = it.filter { c -> c.isDigit() } },
                label = { Text("Minimum Qty") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = supplier,
            onValueChange = { supplier = it },
            label = { Text("Supplier") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val buyingPrice = buyingPriceText.toDoubleOrNull()
                val sellingPrice = sellingPriceText.toDoubleOrNull()
                val quantity = quantityText.toIntOrNull()
                val minQuantity = minQuantityText.toIntOrNull() ?: 2
                when {
                    furnitureName.isBlank() -> errorMessage = "Furniture name daalein"
                    buyingPrice == null -> errorMessage = "Buying price daalein"
                    sellingPrice == null -> errorMessage = "Selling price daalein"
                    quantity == null -> errorMessage = "Quantity daalein"
                    else -> {
                        errorMessage = null
                        viewModel.addItem(
                            furnitureName = furnitureName.trim(),
                            category = category.trim(),
                            buyingPrice = buyingPrice,
                            sellingPrice = sellingPrice,
                            quantity = quantity,
                            minQuantity = minQuantity,
                            supplier = supplier.trim()
                        )
                        onSaved()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Save Stock Item", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}
