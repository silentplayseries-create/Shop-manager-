package com.shopmanager.app.util

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.shopmanager.app.AppContainer
import kotlinx.coroutines.flow.first
import java.text.NumberFormat
import java.util.Locale

class ReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val container = AppContainer(applicationContext)
        val prefs = container.settingsPrefs
        if (!prefs.remindersEnabled) return Result.success()

        NotificationHelper.ensureChannel(applicationContext)

        val pendingOrders = container.orderRepository.getOrdersWithPendingBalance().first()
        if (pendingOrders.isNotEmpty()) {
            val total = pendingOrders.sumOf { it.balance }
            val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
            NotificationHelper.showPendingPaymentReminder(applicationContext, rupeeFormat.format(total), pendingOrders.size)
        }

        val lowStockItems = container.stockRepository.getLowStock().first()
        if (lowStockItems.isNotEmpty()) {
            NotificationHelper.showLowStockReminder(applicationContext, lowStockItems.size)
        }

        return Result.success()
    }
}
