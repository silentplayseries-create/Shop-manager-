package com.shopmanager.app.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shopmanager.app.AppContainer
import com.shopmanager.app.R

private data class BottomTab(val route: String, val labelRes: Int, val icon: ImageVector)

private val bottomTabs = listOf(
    BottomTab(Routes.DASHBOARD, R.string.nav_dashboard, Icons.Default.Dashboard),
    BottomTab(Routes.CUSTOMERS, R.string.nav_customers, Icons.Default.People),
    BottomTab(Routes.ORDERS, R.string.nav_orders, Icons.Default.ShoppingCart),
    BottomTab(Routes.STOCK, R.string.nav_inventory, Icons.Default.Inventory2),
    BottomTab(Routes.REPORTS, R.string.nav_reports, Icons.Default.Assessment),
    BottomTab(Routes.MORE, R.string.nav_more, Icons.Default.MoreHoriz)
)

/**
 * App shell: bottom nav for the primary sections, with the NavHost from
 * NavGraph.kt handling the actual screen routing (including sub-screens
 * like the order/customer forms which don't show in the tab bar).
 */
@Composable
fun ShopManagerApp(container: AppContainer) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                bottomTabs.forEach { tab ->
                    val selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true
                    val label = stringResource(tab.labelRes)
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(bottom = padding.calculateBottomPadding())) {
            ShopManagerNavHost(container = container, navController = navController)
        }
    }
}
