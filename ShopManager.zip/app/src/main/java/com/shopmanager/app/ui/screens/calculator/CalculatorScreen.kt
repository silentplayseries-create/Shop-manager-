package com.shopmanager.app.ui.screens.calculator

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.pow

private enum class CalcTab { NORMAL, GST, DISCOUNT, PROFIT, EMI }

@Composable
fun CalculatorScreen() {
    var selectedTab by remember { mutableStateOf(CalcTab.NORMAL) }
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Calculator", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(selectedTabIndex = selectedTab.ordinal, edgePadding = 0.dp) {
            Tab(selected = selectedTab == CalcTab.NORMAL, onClick = { selectedTab = CalcTab.NORMAL }, text = { Text("Normal") })
            Tab(selected = selectedTab == CalcTab.GST, onClick = { selectedTab = CalcTab.GST }, text = { Text("GST") })
            Tab(selected = selectedTab == CalcTab.DISCOUNT, onClick = { selectedTab = CalcTab.DISCOUNT }, text = { Text("Discount") })
            Tab(selected = selectedTab == CalcTab.PROFIT, onClick = { selectedTab = CalcTab.PROFIT }, text = { Text("Profit") })
            Tab(selected = selectedTab == CalcTab.EMI, onClick = { selectedTab = CalcTab.EMI }, text = { Text("EMI") })
        }
        Spacer(modifier = Modifier.height(20.dp))

        when (selectedTab) {
            CalcTab.NORMAL -> NormalCalculatorTab()
            CalcTab.GST -> GstCalculatorTab(rupeeFormat)
            CalcTab.DISCOUNT -> DiscountCalculatorTab(rupeeFormat)
            CalcTab.PROFIT -> ProfitCalculatorTab(rupeeFormat)
            CalcTab.EMI -> EmiCalculatorTab(rupeeFormat)
        }
    }
}

// --- Normal Calculator ---

@Composable
private fun NormalCalculatorTab() {
    var display by remember { mutableStateOf("0") }
    var storedValue by remember { mutableStateOf<Double?>(null) }
    var pendingOp by remember { mutableStateOf<Char?>(null) }
    var freshEntry by remember { mutableStateOf(true) }

    fun applyOp(a: Double, b: Double, op: Char): Double = when (op) {
        '+' -> a + b
        '-' -> a - b
        '×' -> a * b
        '÷' -> if (b == 0.0) 0.0 else a / b
        else -> b
    }

    fun onDigit(d: String) {
        display = if (freshEntry) d else if (display == "0") d else display + d
        freshEntry = false
    }

    fun onOperator(op: Char) {
        val current = display.toDoubleOrNull() ?: 0.0
        storedValue = if (storedValue == null) current else applyOp(storedValue!!, current, pendingOp ?: '+')
        pendingOp = op
        freshEntry = true
    }

    fun onEquals() {
        val current = display.toDoubleOrNull() ?: 0.0
        val result = if (storedValue != null && pendingOp != null) applyOp(storedValue!!, current, pendingOp!!) else current
        display = formatResult(result)
        storedValue = null
        pendingOp = null
        freshEntry = true
    }

    fun onClear() {
        display = "0"; storedValue = null; pendingOp = null; freshEntry = true
    }

    Column {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = display,
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        val rows = listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "-"),
            listOf("C", "0", "=", "+")
        )
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                row.forEach { label ->
                    OutlinedButton(
                        onClick = {
                            when (label) {
                                "C" -> onClear()
                                "=" -> onEquals()
                                "+", "-", "×", "÷" -> onOperator(label[0])
                                else -> onDigit(label)
                            }
                        },
                        modifier = Modifier.weight(1f).height(60.dp)
                    ) {
                        Text(label, style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
        }
    }
}

private fun formatResult(value: Double): String =
    if (value == value.toLong().toDouble()) value.toLong().toString() else String.format(Locale.US, "%.2f", value)

// --- GST Calculator ---

@Composable
private fun GstCalculatorTab(rupeeFormat: NumberFormat) {
    var amountText by remember { mutableStateOf("") }
    var gstPercentText by remember { mutableStateOf("18") }
    var isAddGst by remember { mutableStateOf(true) }

    val amount = amountText.toDoubleOrNull() ?: 0.0
    val gstPercent = gstPercentText.toDoubleOrNull() ?: 0.0

    // "Add GST" = amount is the base price, GST is added on top.
    // "Remove GST" = amount already includes GST, back out the base price.
    val gstAmount: Double
    val baseAmount: Double
    val totalAmount: Double
    if (isAddGst) {
        baseAmount = amount
        gstAmount = amount * gstPercent / 100.0
        totalAmount = baseAmount + gstAmount
    } else {
        totalAmount = amount
        baseAmount = amount / (1 + gstPercent / 100.0)
        gstAmount = totalAmount - baseAmount
    }

    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = isAddGst, onClick = { isAddGst = true }, label = { Text("Add GST") })
            FilterChip(selected = !isAddGst, onClick = { isAddGst = false }, label = { Text("Remove GST") })
        }
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text(if (isAddGst) "Base Amount" else "Amount (GST included)") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = gstPercentText,
            onValueChange = { gstPercentText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("GST %") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(20.dp))

        ResultCard(
            rows = listOf(
                "Base Amount" to rupeeFormat.format(baseAmount),
                "GST Amount" to rupeeFormat.format(gstAmount),
                "Total" to rupeeFormat.format(totalAmount)
            )
        )
    }
}

// --- Discount Calculator ---

@Composable
private fun DiscountCalculatorTab(rupeeFormat: NumberFormat) {
    var priceText by remember { mutableStateOf("") }
    var discountPercentText by remember { mutableStateOf("") }

    val price = priceText.toDoubleOrNull() ?: 0.0
    val discountPercent = discountPercentText.toDoubleOrNull() ?: 0.0
    val discountAmount = price * discountPercent / 100.0
    val finalPrice = price - discountAmount

    Column {
        OutlinedTextField(
            value = priceText,
            onValueChange = { priceText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Original Price") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = discountPercentText,
            onValueChange = { discountPercentText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Discount %") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(20.dp))

        ResultCard(
            rows = listOf(
                "Discount Amount" to rupeeFormat.format(discountAmount),
                "Final Price" to rupeeFormat.format(finalPrice)
            )
        )
    }
}

// --- Profit Calculator ---

@Composable
private fun ProfitCalculatorTab(rupeeFormat: NumberFormat) {
    var buyingPriceText by remember { mutableStateOf("") }
    var sellingPriceText by remember { mutableStateOf("") }

    val buyingPrice = buyingPriceText.toDoubleOrNull() ?: 0.0
    val sellingPrice = sellingPriceText.toDoubleOrNull() ?: 0.0
    val profit = sellingPrice - buyingPrice
    val marginPercent = if (buyingPrice > 0) (profit / buyingPrice) * 100.0 else 0.0

    Column {
        OutlinedTextField(
            value = buyingPriceText,
            onValueChange = { buyingPriceText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Buying Price") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = sellingPriceText,
            onValueChange = { sellingPriceText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Selling Price") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(20.dp))

        ResultCard(
            rows = listOf(
                if (profit >= 0) "Profit" to rupeeFormat.format(profit) else "Loss" to rupeeFormat.format(-profit),
                "Margin %" to String.format(Locale.US, "%.1f%%", marginPercent)
            )
        )
    }
}

// --- EMI Calculator ---

@Composable
private fun EmiCalculatorTab(rupeeFormat: NumberFormat) {
    var principalText by remember { mutableStateOf("") }
    var rateText by remember { mutableStateOf("") }
    var tenureText by remember { mutableStateOf("") }

    val principal = principalText.toDoubleOrNull() ?: 0.0
    val annualRate = rateText.toDoubleOrNull() ?: 0.0
    val tenureMonths = tenureText.toIntOrNull() ?: 0

    // Standard EMI formula: P x R x (1+R)^N / ((1+R)^N - 1), R = monthly rate
    val monthlyRate = annualRate / 12.0 / 100.0
    val emi = if (principal > 0 && tenureMonths > 0 && monthlyRate > 0) {
        val factor = (1 + monthlyRate).pow(tenureMonths)
        principal * monthlyRate * factor / (factor - 1)
    } else if (principal > 0 && tenureMonths > 0) {
        principal / tenureMonths
    } else 0.0
    val totalPayment = emi * tenureMonths
    val totalInterest = totalPayment - principal

    Column {
        OutlinedTextField(
            value = principalText,
            onValueChange = { principalText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Loan Amount") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = rateText,
            onValueChange = { rateText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Annual Interest Rate %") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = tenureText,
            onValueChange = { tenureText = it.filter { c -> c.isDigit() } },
            label = { Text("Tenure (Months)") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Spacer(modifier = Modifier.height(20.dp))

        ResultCard(
            rows = listOf(
                "Monthly EMI" to rupeeFormat.format(emi),
                "Total Payment" to rupeeFormat.format(totalPayment),
                "Total Interest" to rupeeFormat.format(totalInterest)
            )
        )
    }
}

@Composable
private fun ResultCard(rows: List<Pair<String, String>>) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(modifier = Modifier.padding(20.dp)) {
            rows.forEachIndexed { index, (label, value) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(label, style = MaterialTheme.typography.bodyLarge)
                    Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                if (index != rows.lastIndex) Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}
