package com.shopmanager.app.ui.screens.staff

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Attendance
import com.shopmanager.app.data.local.entity.AttendanceStatus
import com.shopmanager.app.data.local.entity.Staff
import com.shopmanager.app.viewmodel.StaffViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.util.Locale

@Composable
fun StaffScreen(container: AppContainer) {
    val viewModel: StaffViewModel = viewModel(factory = ViewModelFactory(container))
    val staffList by viewModel.staffList.collectAsState()
    val todayAttendance by viewModel.todayAttendance.collectAsState()
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }
    var showAddDialog by remember { mutableStateOf(false) }
    var staffToDelete by remember { mutableStateOf<Staff?>(null) }

    val attendanceByStaffId = remember(todayAttendance) { todayAttendance.associateBy { it.staffId } }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Staff")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Staff", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Aaj ki attendance mark karein",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (staffList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Koi staff add nahi hua")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(staffList, key = { it.id }) { staff ->
                        StaffRow(
                            staff = staff,
                            attendance = attendanceByStaffId[staff.id],
                            rupeeFormat = rupeeFormat,
                            onMarkAttendance = { status -> viewModel.markAttendance(staff.id, status) },
                            onDelete = { staffToDelete = staff }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddStaffDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, mobile, role, salary, notes ->
                viewModel.addStaff(name, mobile, role, salary, notes)
                showAddDialog = false
            }
        )
    }

    staffToDelete?.let { staff ->
        AlertDialog(
            onDismissRequest = { staffToDelete = null },
            title = { Text("Remove Staff?") },
            text = { Text("${staff.name} ko remove karna hai?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteStaff(staff)
                    staffToDelete = null
                }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { staffToDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun StaffRow(
    staff: Staff,
    attendance: Attendance?,
    rupeeFormat: NumberFormat,
    onMarkAttendance: (AttendanceStatus) -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(staff.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (staff.role.isNotBlank()) Text(staff.role, style = MaterialTheme.typography.bodyMedium)
                    if (staff.monthlySalary > 0) Text("Salary: ${rupeeFormat.format(staff.monthlySalary)}/month", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(
                    selected = attendance?.status == AttendanceStatus.PRESENT,
                    onClick = { onMarkAttendance(AttendanceStatus.PRESENT) },
                    label = { Text("Present") }
                )
                FilterChip(
                    selected = attendance?.status == AttendanceStatus.ABSENT,
                    onClick = { onMarkAttendance(AttendanceStatus.ABSENT) },
                    label = { Text("Absent") }
                )
                FilterChip(
                    selected = attendance?.status == AttendanceStatus.HALF_DAY,
                    onClick = { onMarkAttendance(AttendanceStatus.HALF_DAY) },
                    label = { Text("Half Day") }
                )
                FilterChip(
                    selected = attendance?.status == AttendanceStatus.LEAVE,
                    onClick = { onMarkAttendance(AttendanceStatus.LEAVE) },
                    label = { Text("Leave") }
                )
            }
        }
    }
}

@Composable
private fun AddStaffDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var salaryText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Staff") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it; error = null }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it.filter { c -> c.isDigit() }.take(10) },
                    label = { Text("Mobile") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = salaryText,
                    onValueChange = { salaryText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Monthly Salary") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) { error = "Naam daalein"; return@TextButton }
                onSave(name.trim(), mobile, role.trim(), salaryText.toDoubleOrNull() ?: 0.0, notes.trim())
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
