package com.shopmanager.app.ui.theme

import androidx.compose.ui.graphics.Color

// Section 19: UI Theme - Dark Blue, White, Easy Touch Controls
val ShopBlue = Color(0xFF0D47A1)
val ShopBlueDark = Color(0xFF08306B)
val ShopBlueLight = Color(0xFF5472D3)
val ShopBackground = Color(0xFFF5F7FA)
val ShopSurface = Color(0xFFFFFFFF)
val ShopError = Color(0xFFD32F2F)
val ShopSuccess = Color(0xFF2E7D32)
val ShopWarning = Color(0xFFF9A825)
val ShopTextPrimary = Color(0xFF1A1C1E)
val ShopTextSecondary = Color(0xFF5F6368)

// Colorful accent chips for quick-action icons / stat cards, matching the
// reference mockup's style where each action has its own color.
val AccentBlue = Color(0xFF2F6FED)
val AccentGreen = Color(0xFF2FAE60)
val AccentPurple = Color(0xFF8E5CE0)
val AccentOrange = Color(0xFFF08A24)
val AccentPink = Color(0xFFEA4C89)
val AccentTeal = Color(0xFF17A398)
