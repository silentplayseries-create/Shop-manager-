package com.shopmanager.app.ui.theme

import androidx.compose.ui.graphics.Color

// Section 19: UI Theme - Dark Blue, White, Easy Touch Controls
val ShopBlue = Color(0xFF0D47A1)
val ShopBlueDark = Color(0xFF08306B)
val ShopBlueLight = Color(0xFF5472D3)
val ShopBackground = Color(0xFFF5F7FA)
val ShopSurface = Color(0xFFFFFFFF)
val ShopError = Color(0xFFD32F2F)
val ShopSuccess = Color(0xFF2E7D32)
val ShopWarning = Color(0xFFF9A825)
val ShopTextPrimary = Color(0xFF1A1C1E)
val ShopTextSecondary = Color(0xFF5F6368)
