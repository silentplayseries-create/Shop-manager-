package com.shopmanager.app.util

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import android.net.Uri
import com.shopmanager.app.data.local.entity.Order
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Section 21 (Future Features): Invoice PDF. This is a simple, single-page
 * text invoice - no logo/letterhead layout - built with Android's built-in
 * PdfDocument API so no extra library/dependency is needed.
 */
object InvoicePdfGenerator {

    fun generate(
        context: Context,
        shopName: String,
        ownerName: String,
        customerName: String,
        customerMobile: String,
        order: Order
    ): Uri {
        val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

        val pageWidth = 595 // A4 at 72dpi
        val pageHeight = 842
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true }
        val headerPaint = Paint().apply { textSize = 14f; isFakeBoldText = true }
        val bodyPaint = Paint().apply { textSize = 12f }

        var y = 50f
        val left = 40f

        canvas.drawText(shopName.ifBlank { "Shop Manager" }, left, y, titlePaint)
        y += 20f
        if (ownerName.isNotBlank()) {
            canvas.drawText("Owner: $ownerName", left, y, bodyPaint)
            y += 18f
        }
        canvas.drawText("Invoice generated: ${dateFormat.format(Date())}", left, y, bodyPaint)
        y += 30f

        canvas.drawLine(left, y, pageWidth - left, y, bodyPaint)
        y += 30f

        canvas.drawText("Bill To", left, y, headerPaint)
        y += 20f
        canvas.drawText(customerName, left, y, bodyPaint)
        y += 18f
        if (customerMobile.isNotBlank()) {
            canvas.drawText(customerMobile, left, y, bodyPaint)
            y += 18f
        }
        y += 20f

        canvas.drawText("Order Details", left, y, headerPaint)
        y += 20f
        val lines = listOf(
            "Item" to "${order.furnitureName} (${order.category})",
            "Quantity" to order.quantity.toString(),
            "Unit Price" to rupeeFormat.format(order.price),
            "Discount" to rupeeFormat.format(order.discount),
            "GST" to "${order.gstPercent}%",
            "Total" to rupeeFormat.format(order.total),
            "Advance Paid" to rupeeFormat.format(order.advance),
            "Balance Due" to rupeeFormat.format(order.balance)
        )
        lines.forEach { (label, value) ->
            canvas.drawText(label, left, y, bodyPaint)
            canvas.drawText(value, left + 200f, y, bodyPaint)
            y += 20f
        }

        y += 20f
        canvas.drawLine(left, y, pageWidth - left, y, bodyPaint)
        y += 24f
        canvas.drawText("Thank you for your business!", left, y, bodyPaint)

        document.finishPage(page)

        val invoicesDir = File(context.cacheDir, "invoices").apply { mkdirs() }
        val file = File(invoicesDir, "invoice_${order.id}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { document.writeTo(it) }
        document.close()

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }
}
