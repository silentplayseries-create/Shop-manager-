package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class PaymentMode {
    CASH, UPI, BANK, CARD, CHEQUE, UDHAR
}

enum class OrderStatus {
    PENDING, OUT_FOR_DELIVERY, DELIVERED, CANCELLED
}

/**
 * Orders Module (Master Spec Section 8)
 * Total / Balance are calculated at write-time (not just in the UI) so
 * reports (Section 11) can query them directly without recomputation.
 */
@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId")]
)
data class Order(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val furnitureName: String,
    val category: String,
    val quantity: Int,
    val price: Double,
    val discount: Double = 0.0,
    val gstPercent: Double = 0.0,
    val total: Double,
    val advance: Double = 0.0,
    val balance: Double,
    val deliveryDate: Long? = null,
    val paymentMode: PaymentMode = PaymentMode.CASH,
    val notes: String = "",
    val status: OrderStatus = OrderStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        /**
         * Section 12 (Calculator module) shares this same math, so keep
         * the formula in one place: total = (qty*price - discount) + gst.
         */
        fun calculateTotal(quantity: Int, price: Double, discount: Double, gstPercent: Double): Double {
            val subtotal = (quantity * price) - discount
            val gstAmount = subtotal * (gstPercent / 100.0)
            return subtotal + gstAmount
        }
    }
}
