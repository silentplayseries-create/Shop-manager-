package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.StockItem
import com.shopmanager.app.data.repository.StockRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StockViewModel(private val repository: StockRepository) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val stockItems: StateFlow<List<StockItem>> = _searchQuery
        .flatMapLatest { query -> repository.search(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun addItem(
        furnitureName: String,
        category: String,
        buyingPrice: Double,
        sellingPrice: Double,
        quantity: Int,
        minQuantity: Int,
        supplier: String,
        imagePath: String = ""
    ) {
        viewModelScope.launch {
            repository.add(
                StockItem(
                    furnitureName = furnitureName,
                    category = category,
                    buyingPrice = buyingPrice,
                    sellingPrice = sellingPrice,
                    quantity = quantity,
                    minQuantity = minQuantity,
                    supplier = supplier,
                    imagePath = imagePath
                )
            )
        }
    }

    fun updateItem(item: StockItem) {
        viewModelScope.launch { repository.update(item) }
    }

    fun deleteItem(item: StockItem) {
        viewModelScope.launch { repository.delete(item) }
    }

    /** Re-inserts a just-deleted item with its original id, for the Undo snackbar action. */
    fun restoreItem(item: StockItem) {
        viewModelScope.launch { repository.add(item) }
    }
}
