package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Payment Module (Master Spec Section 9)
 * A separate table (rather than just editing Order.advance) so a
 * customer's account can show full Payment History over time, e.g.
 * multiple part-payments against one order or general udhar clearance.
 */
@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Order::class,
            parentColumns = ["id"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("customerId"), Index("orderId")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val orderId: Long? = null,
    val amount: Double,
    val mode: PaymentMode = PaymentMode.CASH,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
