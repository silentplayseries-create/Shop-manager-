package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DeliveryViewModel(
    private val orderRepository: OrderRepository,
    customerRepository: CustomerRepository
) : ViewModel() {

    val orders: StateFlow<List<Order>> = orderRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers = customerRepository.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun markOutForDelivery(order: Order) {
        viewModelScope.launch {
            orderRepository.updateOrder(order, order.copy(status = OrderStatus.OUT_FOR_DELIVERY))
        }
    }

    fun markDelivered(order: Order) {
        viewModelScope.launch {
            orderRepository.updateOrder(order, order.copy(status = OrderStatus.DELIVERED))
        }
    }

    fun setDeliveryDate(order: Order, deliveryDate: Long) {
        viewModelScope.launch {
            orderRepository.updateOrder(order, order.copy(deliveryDate = deliveryDate))
        }
    }
}
