package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.SupplierDao
import com.shopmanager.app.data.local.entity.Supplier
import kotlinx.coroutines.flow.Flow

class SupplierRepository(private val supplierDao: SupplierDao) {

    fun getAll(): Flow<List<Supplier>> = supplierDao.getAll()

    fun search(query: String): Flow<List<Supplier>> =
        if (query.isBlank()) supplierDao.getAll() else supplierDao.search(query)

    suspend fun add(supplier: Supplier): Long = supplierDao.insert(supplier)

    suspend fun update(supplier: Supplier) = supplierDao.update(supplier)

    suspend fun delete(supplier: Supplier) = supplierDao.delete(supplier)
}
