package com.shopmanager.app.data.local.dao

import androidx.room.*
import com.shopmanager.app.data.local.entity.Attendance
import com.shopmanager.app.data.local.entity.Staff
import kotlinx.coroutines.flow.Flow

@Dao
interface StaffDao {

    @Query("SELECT * FROM staff ORDER BY name ASC")
    fun getAll(): Flow<List<Staff>>

    @Insert
    suspend fun insert(staff: Staff): Long

    @Update
    suspend fun update(staff: Staff)

    @Delete
    suspend fun delete(staff: Staff)

    @Query("SELECT * FROM staff")
    suspend fun getAllOnce(): List<Staff>

    @Query("DELETE FROM staff")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(staff: List<Staff>)
}

@Dao
interface AttendanceDao {

    @Query("SELECT * FROM attendance WHERE dayKey = :dayKey")
    fun getForDay(dayKey: String): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE staffId = :staffId ORDER BY dayKey DESC")
    fun getForStaff(staffId: Long): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE staffId = :staffId AND dayKey = :dayKey LIMIT 1")
    suspend fun getForStaffAndDay(staffId: Long, dayKey: String): Attendance?

    @Insert
    suspend fun insert(attendance: Attendance): Long

    @Update
    suspend fun update(attendance: Attendance)

    @Query("SELECT COUNT(*) FROM attendance WHERE dayKey = :dayKey AND status = 'PRESENT'")
    fun getPresentCountForDay(dayKey: String): Flow<Int>

    @Query("SELECT * FROM attendance")
    suspend fun getAllOnce(): List<Attendance>

    @Query("DELETE FROM attendance")
    suspend fun clearAll()

    @Insert
    suspend fun insertAll(records: List<Attendance>)
}
