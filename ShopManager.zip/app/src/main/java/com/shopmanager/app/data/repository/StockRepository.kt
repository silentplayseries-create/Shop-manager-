package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.StockDao
import com.shopmanager.app.data.local.entity.StockItem
import kotlinx.coroutines.flow.Flow

class StockRepository(private val stockDao: StockDao) {

    fun getAll(): Flow<List<StockItem>> = stockDao.getAll()

    fun search(query: String): Flow<List<StockItem>> =
        if (query.isBlank()) stockDao.getAll() else stockDao.search(query)

    fun getLowStock(): Flow<List<StockItem>> = stockDao.getLowStock()

    fun getLowStockCount(): Flow<Int> = stockDao.getLowStockCount()

    suspend fun getById(id: Long): StockItem? = stockDao.getById(id)

    suspend fun findByName(name: String): StockItem? = stockDao.findByName(name)

    suspend fun add(item: StockItem): Long = stockDao.insert(item)

    suspend fun update(item: StockItem) = stockDao.update(item)

    suspend fun delete(item: StockItem) = stockDao.delete(item)
}
