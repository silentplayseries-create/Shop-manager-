package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Customer Module (Master Spec Section 7)
 * totalPurchase / totalPaid / totalDue are kept as denormalized running
 * totals on the customer row so the dashboard and customer list can be
 * read in a single query without joining/summing Orders every time.
 * They are updated whenever an Order or Payment is created/edited.
 */
@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val mobile: String,
    val address: String = "",
    val notes: String = "",
    val totalPurchase: Double = 0.0,
    val totalPaid: Double = 0.0,
    val totalDue: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)
