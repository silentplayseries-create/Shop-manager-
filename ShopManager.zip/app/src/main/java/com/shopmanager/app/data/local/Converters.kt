package com.shopmanager.app.data.local

import androidx.room.TypeConverter
import com.shopmanager.app.data.local.entity.AttendanceStatus
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.data.local.entity.PaymentMode

class Converters {

    @TypeConverter
    fun fromPaymentMode(mode: PaymentMode): String = mode.name

    @TypeConverter
    fun toPaymentMode(value: String): PaymentMode = PaymentMode.valueOf(value)

    @TypeConverter
    fun fromOrderStatus(status: OrderStatus): String = status.name

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus = OrderStatus.valueOf(value)

    @TypeConverter
    fun fromAttendanceStatus(status: AttendanceStatus): String = status.name

    @TypeConverter
    fun toAttendanceStatus(value: String): AttendanceStatus = AttendanceStatus.valueOf(value)
}
