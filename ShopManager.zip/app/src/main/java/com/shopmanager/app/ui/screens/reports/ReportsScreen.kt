package com.shopmanager.app.ui.screens.reports

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.ui.components.charts.BarDatum
import com.shopmanager.app.ui.components.charts.DonutChart
import com.shopmanager.app.ui.components.charts.DonutSlice
import com.shopmanager.app.ui.components.charts.HorizontalBarChart
import com.shopmanager.app.ui.components.charts.LineChart
import com.shopmanager.app.ui.components.charts.LinePoint
import com.shopmanager.app.viewmodel.ReportRange
import com.shopmanager.app.viewmodel.ReportsViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class ReportTab { SALES, CUSTOMERS, STOCK, PROFIT, PENDING }

private val CHART_PALETTE = listOf(
    Color(0xFF0D47A1), Color(0xFF00897B), Color(0xFFF9A825),
    Color(0xFF8E24AA), Color(0xFFD32F2F), Color(0xFF5472D3)
)

@Composable
fun ReportsScreen(container: AppContainer) {
    val viewModel: ReportsViewModel = viewModel(factory = ViewModelFactory(container))
    val orders by viewModel.orders.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val stockItems by viewModel.stockItems.collectAsState()
    val profitResult by viewModel.profitResult.collectAsState()
    val isCalculatingProfit by viewModel.isCalculatingProfit.collectAsState()
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    var selectedTab by remember { mutableStateOf(ReportTab.SALES) }
    var selectedRange by remember { mutableStateOf(ReportRange.TODAY) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Reports", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(selectedTabIndex = selectedTab.ordinal, edgePadding = 0.dp) {
            Tab(selected = selectedTab == ReportTab.SALES, onClick = { selectedTab = ReportTab.SALES }, text = { Text("Sales") })
            Tab(selected = selectedTab == ReportTab.CUSTOMERS, onClick = { selectedTab = ReportTab.CUSTOMERS }, text = { Text("Customers") })
            Tab(selected = selectedTab == ReportTab.STOCK, onClick = { selectedTab = ReportTab.STOCK }, text = { Text("Stock") })
            Tab(selected = selectedTab == ReportTab.PROFIT, onClick = { selectedTab = ReportTab.PROFIT }, text = { Text("Profit") })
            Tab(selected = selectedTab == ReportTab.PENDING, onClick = { selectedTab = ReportTab.PENDING }, text = { Text("Pending") })
        }
        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            when (selectedTab) {
                ReportTab.SALES -> SalesReportTab(orders, selectedRange, { selectedRange = it }, viewModel, rupeeFormat)
                ReportTab.CUSTOMERS -> CustomerReportTab(customers, rupeeFormat)
                ReportTab.STOCK -> StockReportTab(stockItems, rupeeFormat)
                ReportTab.PROFIT -> ProfitReportTab(profitResult, isCalculatingProfit, rupeeFormat) { viewModel.calculateProfit() }
                ReportTab.PENDING -> PendingReportTab(orders.filter { it.balance > 0 }, rupeeFormat)
            }
        }
    }
}

@Composable
private fun StatMiniCard(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}

@Composable
private fun SalesReportTab(
    allOrders: List<Order>,
    selectedRange: ReportRange,
    onRangeChange: (ReportRange) -> Unit,
    viewModel: ReportsViewModel,
    rupeeFormat: NumberFormat
) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(
                ReportRange.TODAY to "Today",
                ReportRange.WEEK to "Week",
                ReportRange.MONTH to "Month",
                ReportRange.YEAR to "Year"
            ).forEach { (range, label) ->
                FilterChip(selected = selectedRange == range, onClick = { onRangeChange(range) }, label = { Text(label) })
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        val totalSale = viewModel.salesTotalFor(selectedRange)
        val orderCount = viewModel.orderCountFor(selectedRange)
        val avgOrderValue = if (orderCount > 0) totalSale / orderCount else 0.0
        val pendingTotal = remember(allOrders) { allOrders.filter { it.balance > 0 }.sumOf { it.balance } }

        // Stat cards row - mirrors the "Total Revenue / Orders / AOV" row style
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatMiniCard("Total Sale", rupeeFormat.format(totalSale), Icons.Default.CurrencyRupee, Modifier.weight(1f))
            StatMiniCard("Orders", orderCount.toString(), Icons.Default.ShoppingCart, Modifier.weight(1f))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatMiniCard("Avg Order", rupeeFormat.format(avgOrderValue), Icons.Default.TrendingUp, Modifier.weight(1f))
            StatMiniCard("Pending", rupeeFormat.format(pendingTotal), Icons.Default.Warning, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Revenue trend - last 7 days
        Text("Revenue Trend (Last 7 Days)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(12.dp))
        Card {
            Box(modifier = Modifier.padding(16.dp)) {
                val trendPoints = remember(allOrders) { last7DaysTrend(allOrders) }
                LineChart(points = trendPoints, modifier = Modifier.fillMaxWidth())
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Revenue by category
        Text("Revenue by Category", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(12.dp))
        Card {
            Box(modifier = Modifier.padding(16.dp)) {
                val categoryData = remember(allOrders) { revenueByCategory(allOrders, rupeeFormat) }
                if (categoryData.isEmpty()) {
                    Text("Abhi koi order nahi hai")
                } else {
                    HorizontalBarChart(data = categoryData, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Payment mode mix
        Text("Payment Mode Mix", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(12.dp))
        Card {
            Box(modifier = Modifier.padding(16.dp)) {
                val slices = remember(allOrders) { paymentModeMix(allOrders, rupeeFormat) }
                if (slices.isEmpty()) {
                    Text("Abhi koi order nahi hai")
                } else {
                    DonutChart(
                        slices = slices,
                        centerLabel = "Total",
                        centerValue = rupeeFormat.format(allOrders.sumOf { it.total }).let {
                            if (it.length > 10) rupeeFormat.format(allOrders.sumOf { o -> o.total } / 1000.0) + "K" else it
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

private fun last7DaysTrend(orders: List<Order>): List<LinePoint> {
    val dayFormat = SimpleDateFormat("dd MMM", Locale.getDefault())
    val cal = Calendar.getInstance()
    val points = mutableListOf<LinePoint>()
    for (i in 6 downTo 0) {
        val dayCal = cal.clone() as Calendar
        dayCal.add(Calendar.DAY_OF_MONTH, -i)
        dayCal.set(Calendar.HOUR_OF_DAY, 0); dayCal.set(Calendar.MINUTE, 0); dayCal.set(Calendar.SECOND, 0)
        val dayStart = dayCal.timeInMillis
        val dayEnd = dayStart + 24L * 60 * 60 * 1000
        val total = orders.filter { it.createdAt in dayStart until dayEnd }.sumOf { it.total }
        points.add(LinePoint(dayFormat.format(Date(dayStart)), total))
    }
    return points
}

private fun revenueByCategory(orders: List<Order>, rupeeFormat: NumberFormat): List<BarDatum> {
    return orders.groupBy { it.category.ifBlank { "Other" } }
        .mapValues { (_, list) -> list.sumOf { it.total } }
        .entries.sortedByDescending { it.value }
        .take(6)
        .map { BarDatum(it.key, it.value, rupeeFormat.format(it.value)) }
}

private fun paymentModeMix(orders: List<Order>, rupeeFormat: NumberFormat): List<DonutSlice> {
    return orders.groupBy { it.paymentMode }
        .mapValues { (_, list) -> list.sumOf { it.total } }
        .entries.sortedByDescending { it.value }
        .mapIndexed { index, entry ->
            DonutSlice(
                label = entry.key.name,
                value = entry.value,
                color = CHART_PALETTE[index % CHART_PALETTE.size],
                displayValue = rupeeFormat.format(entry.value)
            )
        }
}

@Composable
private fun CustomerReportTab(
    customers: List<com.shopmanager.app.data.local.entity.Customer>,
    rupeeFormat: NumberFormat
) {
    val sorted = remember(customers) { customers.sortedByDescending { it.totalDue } }
    if (sorted.isEmpty()) {
        Text("Koi customer nahi hai")
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        sorted.forEach { customer ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(customer.name, fontWeight = FontWeight.SemiBold)
                    Text("Purchase: ${rupeeFormat.format(customer.totalPurchase)}  •  Paid: ${rupeeFormat.format(customer.totalPaid)}")
                    if (customer.totalDue > 0) {
                        Text("Due: ${rupeeFormat.format(customer.totalDue)}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StockReportTab(
    stockItems: List<com.shopmanager.app.data.local.entity.StockItem>,
    rupeeFormat: NumberFormat
) {
    if (stockItems.isEmpty()) {
        Text("Koi stock item nahi hai")
        return
    }
    val lowStock = stockItems.filter { it.isLowStock }
    Column {
        if (lowStock.isNotEmpty()) {
            Text("Low Stock (${lowStock.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.height(8.dp))
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            stockItems.forEach { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("${item.furnitureName} (${item.category})", fontWeight = FontWeight.SemiBold)
                        Text("Qty: ${item.quantity}  •  Value: ${rupeeFormat.format(item.sellingPrice * item.quantity)}")
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfitReportTab(
    result: com.shopmanager.app.viewmodel.ProfitResult?,
    isCalculating: Boolean,
    rupeeFormat: NumberFormat,
    onCalculate: () -> Unit
) {
    Column {
        Text(
            "Profit tabhi accurately calculate hoga jab order ka furniture name Stock me bhi add ho (Buying Price match karne ke liye).",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onCalculate, enabled = !isCalculating) {
            Text(if (isCalculating) "Calculating..." else "Calculate Profit")
        }
        Spacer(modifier = Modifier.height(16.dp))
        result?.let {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Estimated Profit", style = MaterialTheme.typography.titleMedium)
                    Text(rupeeFormat.format(it.totalProfit), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("${it.ordersMatched} orders matched with Stock, ${it.ordersUnmatched} skipped (no matching Stock item)")
                }
            }
        }
    }
}

@Composable
private fun PendingReportTab(
    pendingOrders: List<Order>,
    rupeeFormat: NumberFormat
) {
    if (pendingOrders.isEmpty()) {
        Text("Koi pending payment nahi hai 🎉")
        return
    }
    val totalPending = remember(pendingOrders) { pendingOrders.sumOf { it.balance } }
    Column {
        Text("Total Pending: ${rupeeFormat.format(totalPending)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            pendingOrders.forEach { order ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(order.furnitureName, fontWeight = FontWeight.SemiBold)
                        Text("Balance: ${rupeeFormat.format(order.balance)}", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
