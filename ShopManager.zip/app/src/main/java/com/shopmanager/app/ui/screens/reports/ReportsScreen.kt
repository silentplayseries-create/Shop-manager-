package com.shopmanager.app.ui.screens.reports

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.viewmodel.ReportRange
import com.shopmanager.app.viewmodel.ReportsViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.util.Locale

private enum class ReportTab { SALES, CUSTOMERS, STOCK, PROFIT, PENDING }

@Composable
fun ReportsScreen(container: AppContainer) {
    val viewModel: ReportsViewModel = viewModel(factory = ViewModelFactory(container))
    val orders by viewModel.orders.collectAsState()
    val customers by viewModel.customers.collectAsState()
    val stockItems by viewModel.stockItems.collectAsState()
    val profitResult by viewModel.profitResult.collectAsState()
    val isCalculatingProfit by viewModel.isCalculatingProfit.collectAsState()
    val rupeeFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

    var selectedTab by remember { mutableStateOf(ReportTab.SALES) }
    var selectedRange by remember { mutableStateOf(ReportRange.TODAY) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Reports", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(selectedTabIndex = selectedTab.ordinal, edgePadding = 0.dp) {
            Tab(selected = selectedTab == ReportTab.SALES, onClick = { selectedTab = ReportTab.SALES }, text = { Text("Sales") })
            Tab(selected = selectedTab == ReportTab.CUSTOMERS, onClick = { selectedTab = ReportTab.CUSTOMERS }, text = { Text("Customers") })
            Tab(selected = selectedTab == ReportTab.STOCK, onClick = { selectedTab = ReportTab.STOCK }, text = { Text("Stock") })
            Tab(selected = selectedTab == ReportTab.PROFIT, onClick = { selectedTab = ReportTab.PROFIT }, text = { Text("Profit") })
            Tab(selected = selectedTab == ReportTab.PENDING, onClick = { selectedTab = ReportTab.PENDING }, text = { Text("Pending") })
        }
        Spacer(modifier = Modifier.height(16.dp))

        when (selectedTab) {
            ReportTab.SALES -> SalesReportTab(orders.size, selectedRange, { selectedRange = it }, viewModel, rupeeFormat)
            ReportTab.CUSTOMERS -> CustomerReportTab(customers, rupeeFormat)
            ReportTab.STOCK -> StockReportTab(stockItems, rupeeFormat)
            ReportTab.PROFIT -> ProfitReportTab(profitResult, isCalculatingProfit, rupeeFormat) { viewModel.calculateProfit() }
            ReportTab.PENDING -> PendingReportTab(orders.filter { it.balance > 0 }, rupeeFormat)
        }
    }
}

@Composable
private fun SalesReportTab(
    orderCountTotal: Int,
    selectedRange: ReportRange,
    onRangeChange: (ReportRange) -> Unit,
    viewModel: ReportsViewModel,
    rupeeFormat: NumberFormat
) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(
                ReportRange.TODAY to "Today",
                ReportRange.WEEK to "Week",
                ReportRange.MONTH to "Month",
                ReportRange.YEAR to "Year"
            ).forEach { (range, label) ->
                FilterChip(
                    selected = selectedRange == range,
                    onClick = { onRangeChange(range) },
                    label = { Text(label) }
                )
            }
        }
        Spacer(modifier = Modifier.height(20.dp))

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Total Sale", style = MaterialTheme.typography.titleMedium)
                Text(
                    rupeeFormat.format(viewModel.salesTotalFor(selectedRange)),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("${viewModel.orderCountFor(selectedRange)} orders")
            }
        }
    }
}

@Composable
private fun CustomerReportTab(
    customers: List<com.shopmanager.app.data.local.entity.Customer>,
    rupeeFormat: NumberFormat
) {
    val sorted = remember(customers) { customers.sortedByDescending { it.totalDue } }
    if (sorted.isEmpty()) {
        Text("Koi customer nahi hai")
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(sorted, key = { it.id }) { customer ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(customer.name, fontWeight = FontWeight.SemiBold)
                    Text("Purchase: ${rupeeFormat.format(customer.totalPurchase)}  •  Paid: ${rupeeFormat.format(customer.totalPaid)}")
                    if (customer.totalDue > 0) {
                        Text("Due: ${rupeeFormat.format(customer.totalDue)}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StockReportTab(
    stockItems: List<com.shopmanager.app.data.local.entity.StockItem>,
    rupeeFormat: NumberFormat
) {
    if (stockItems.isEmpty()) {
        Text("Koi stock item nahi hai")
        return
    }
    val lowStock = stockItems.filter { it.isLowStock }
    Column {
        if (lowStock.isNotEmpty()) {
            Text("Low Stock (${lowStock.size})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.height(8.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(stockItems, key = { it.id }) { item ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("${item.furnitureName} (${item.category})", fontWeight = FontWeight.SemiBold)
                        Text("Qty: ${item.quantity}  •  Value: ${rupeeFormat.format(item.sellingPrice * item.quantity)}")
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfitReportTab(
    result: com.shopmanager.app.viewmodel.ProfitResult?,
    isCalculating: Boolean,
    rupeeFormat: NumberFormat,
    onCalculate: () -> Unit
) {
    Column {
        Text(
            "Profit tabhi accurately calculate hoga jab order ka furniture name Stock me bhi add ho (Buying Price match karne ke liye).",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onCalculate, enabled = !isCalculating) {
            Text(if (isCalculating) "Calculating..." else "Calculate Profit")
        }
        Spacer(modifier = Modifier.height(16.dp))
        result?.let {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Estimated Profit", style = MaterialTheme.typography.titleMedium)
                    Text(rupeeFormat.format(it.totalProfit), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("${it.ordersMatched} orders matched with Stock, ${it.ordersUnmatched} skipped (no matching Stock item)")
                }
            }
        }
    }
}

@Composable
private fun PendingReportTab(
    pendingOrders: List<com.shopmanager.app.data.local.entity.Order>,
    rupeeFormat: NumberFormat
) {
    if (pendingOrders.isEmpty()) {
        Text("Koi pending payment nahi hai 🎉")
        return
    }
    val totalPending = remember(pendingOrders) { pendingOrders.sumOf { it.balance } }
    Column {
        Text("Total Pending: ${rupeeFormat.format(totalPending)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(pendingOrders, key = { it.id }) { order ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(order.furnitureName, fontWeight = FontWeight.SemiBold)
                        Text("Balance: ${rupeeFormat.format(order.balance)}", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
