package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val todaySale: Double = 0.0,
    val todayOrders: Int = 0,
    val pendingDelivery: Int = 0,
    val pendingPayments: Double = 0.0,
    val totalCustomers: Int = 0
)

class DashboardViewModel(
    orderRepository: OrderRepository,
    customerRepository: CustomerRepository
) : ViewModel() {

    val uiState = combine(
        orderRepository.getTodaySaleTotal(),
        orderRepository.getTodayOrderCount(),
        orderRepository.getPendingDeliveryCount(),
        orderRepository.getTotalPendingPayments(),
        customerRepository.getCustomerCount()
    ) { todaySale, todayOrders, pendingDelivery, pendingPayments, totalCustomers ->
        DashboardUiState(todaySale, todayOrders, pendingDelivery, pendingPayments, totalCustomers)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )
}
