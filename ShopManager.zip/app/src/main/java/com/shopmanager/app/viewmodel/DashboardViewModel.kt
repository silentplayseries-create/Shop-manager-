package com.shopmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shopmanager.app.data.repository.CustomerRepository
import com.shopmanager.app.data.repository.OrderRepository
import com.shopmanager.app.data.repository.StockRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val todaySale: Double = 0.0,
    val todayOrders: Int = 0,
    val pendingDelivery: Int = 0,
    val pendingPayments: Double = 0.0,
    val totalCustomers: Int = 0,
    val lowStockCount: Int = 0
)

private data class PartialDashboardState(
    val todaySale: Double,
    val todayOrders: Int,
    val pendingDelivery: Int,
    val pendingPayments: Double,
    val totalCustomers: Int
)

class DashboardViewModel(
    orderRepository: OrderRepository,
    customerRepository: CustomerRepository,
    stockRepository: StockRepository
) : ViewModel() {

    private val partialState = combine(
        orderRepository.getTodaySaleTotal(),
        orderRepository.getTodayOrderCount(),
        orderRepository.getPendingDeliveryCount(),
        orderRepository.getTotalPendingPayments(),
        customerRepository.getCustomerCount()
    ) { todaySale, todayOrders, pendingDelivery, pendingPayments, totalCustomers ->
        PartialDashboardState(todaySale, todayOrders, pendingDelivery, pendingPayments, totalCustomers)
    }

    val uiState = combine(partialState, stockRepository.getLowStockCount()) { partial, lowStockCount ->
        DashboardUiState(
            todaySale = partial.todaySale,
            todayOrders = partial.todayOrders,
            pendingDelivery = partial.pendingDelivery,
            pendingPayments = partial.pendingPayments,
            totalCustomers = partial.totalCustomers,
            lowStockCount = lowStockCount
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )
}
