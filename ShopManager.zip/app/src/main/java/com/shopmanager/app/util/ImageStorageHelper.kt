package com.shopmanager.app.util

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Copies a picked image (from the gallery/file picker) into the app's
 * private storage, so the reference stays valid even if the person deletes
 * the original photo or the content:// permission is later revoked.
 */
object ImageStorageHelper {

    fun copyToInternalStorage(context: Context, sourceUri: Uri, folderName: String): String? {
        return try {
            val folder = File(context.filesDir, folderName).apply { mkdirs() }
            val destFile = File(folder, "img_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            destFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
