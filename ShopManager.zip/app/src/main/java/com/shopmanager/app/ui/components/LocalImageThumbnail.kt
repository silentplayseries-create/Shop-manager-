package com.shopmanager.app.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale

/**
 * Shows a photo from local storage (via ImageStorageHelper), or a generic
 * placeholder icon if no image has been added yet. Loads with plain
 * BitmapFactory since the app has no image-loading library dependency.
 */
@Composable
fun LocalImageThumbnail(
    imagePath: String,
    modifier: Modifier = Modifier,
    cornerRadius: Int = 12
) {
    val bitmap = remember(imagePath) {
        if (imagePath.isBlank()) null
        else runCatching { BitmapFactory.decodeFile(imagePath)?.asImageBitmap() }.getOrNull()
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = "Furniture photo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(
                imageVector = Icons.Default.Chair,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}
