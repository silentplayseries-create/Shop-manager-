package com.shopmanager.app.ui.screens.order

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shopmanager.app.AppContainer
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.viewmodel.CustomerViewModel
import com.shopmanager.app.viewmodel.OrderViewModel
import com.shopmanager.app.viewmodel.ViewModelFactory
import java.text.NumberFormat
import java.util.Locale

@Composable
fun OrderFormScreen(
    container: AppContainer,
    onSaved: () -> Unit
) {
    val orderViewModel: OrderViewModel = viewModel(factory = ViewModelFactory(container))
    val customerViewModel: CustomerViewModel = viewModel(factory = ViewModelFactory(container))
    val customers by customerViewModel.customers.collectAsState()
    val rupeeFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var customerDropdownExpanded by remember { mutableStateOf(false) }

    var furnitureName by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("1") }
    var priceText by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("0") }
    var gstText by remember { mutableStateOf("0") }
    var advanceText by remember { mutableStateOf("0") }
    var paymentMode by remember { mutableStateOf(PaymentMode.CASH) }
    var paymentDropdownExpanded by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Section 12: Auto Calculation - recomputes live as the shop owner types,
    // same formula the standalone GST/Discount calculator uses.
    val quantity = quantityText.toIntOrNull() ?: 0
    val price = priceText.toDoubleOrNull() ?: 0.0
    val discount = discountText.toDoubleOrNull() ?: 0.0
    val gstPercent = gstText.toDoubleOrNull() ?: 0.0
    val advance = advanceText.toDoubleOrNull() ?: 0.0
    val total = Order.calculateTotal(quantity, price, discount, gstPercent)
    val balance = (total - advance).coerceAtLeast(0.0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("New Order", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        // Customer picker
        ExposedDropdownMenuBox(
            expanded = customerDropdownExpanded,
            onExpandedChange = { customerDropdownExpanded = it }
        ) {
            OutlinedTextField(
                value = selectedCustomer?.name ?: "",
                onValueChange = {},
                readOnly = true,
                label = { Text("Customer") },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = customerDropdownExpanded,
                onDismissRequest = { customerDropdownExpanded = false }
            ) {
                if (customers.isEmpty()) {
                    DropdownMenuItem(text = { Text("Pehle ek customer add karein") }, onClick = {})
                }
                customers.forEach { customer ->
                    DropdownMenuItem(
                        text = { Text("${customer.name} (${customer.mobile})") },
                        onClick = {
                            selectedCustomer = customer
                            customerDropdownExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = furnitureName,
            onValueChange = { furnitureName = it },
            label = { Text("Furniture Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = quantityText,
                onValueChange = { quantityText = it.filter { c -> c.isDigit() } },
                label = { Text("Quantity") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Price") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = discountText,
                onValueChange = { discountText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("Discount (₹)") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedTextField(
                value = gstText,
                onValueChange = { gstText = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("GST %") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = advanceText,
            onValueChange = { advanceText = it.filter { c -> c.isDigit() || c == '.' } },
            label = { Text("Advance Paid (₹)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Payment mode picker
        ExposedDropdownMenuBox(
            expanded = paymentDropdownExpanded,
            onExpandedChange = { paymentDropdownExpanded = it }
        ) {
            OutlinedTextField(
                value = paymentMode.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("Payment Mode") },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = paymentDropdownExpanded,
                onDismissRequest = { paymentDropdownExpanded = false }
            ) {
                PaymentMode.values().forEach { mode ->
                    DropdownMenuItem(
                        text = { Text(mode.name) },
                        onClick = {
                            paymentMode = mode
                            paymentDropdownExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = notes,
            onValueChange = { notes = it },
            label = { Text("Notes") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Live total/balance preview - Section 12 Auto Calculation
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total")
                    Text(rupeeFormat.format(total), fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Balance Due")
                    Text(rupeeFormat.format(balance), fontWeight = FontWeight.Bold)
                }
            }
        }

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                val customer = selectedCustomer
                when {
                    customer == null -> errorMessage = "Customer select karein"
                    furnitureName.isBlank() -> errorMessage = "Furniture name daalein"
                    quantity <= 0 -> errorMessage = "Quantity 0 se zyada honi chahiye"
                    price <= 0.0 -> errorMessage = "Price daalein"
                    else -> {
                        errorMessage = null
                        orderViewModel.addOrder(
                            customerId = customer.id,
                            furnitureName = furnitureName.trim(),
                            category = category.trim(),
                            quantity = quantity,
                            price = price,
                            discount = discount,
                            gstPercent = gstPercent,
                            advance = advance,
                            deliveryDate = null,
                            paymentMode = paymentMode,
                            notes = notes.trim()
                        )
                        onSaved()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Save Order", style = MaterialTheme.typography.titleMedium)
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
