package com.shopmanager.app.ui.screens.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.shopmanager.app.AppContainer
import com.shopmanager.app.R
import com.shopmanager.app.data.local.ThemeMode
import com.shopmanager.app.util.LocaleHelper
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(container: AppContainer) {
    val prefs = container.settingsPrefs
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val biometricAvailable = remember {
        BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }

    var shopName by remember { mutableStateOf(prefs.shopName) }
    var ownerName by remember { mutableStateOf(prefs.ownerName) }
    var facebookUrl by remember { mutableStateOf(prefs.facebookUrl) }
    var instagramUrl by remember { mutableStateOf(prefs.instagramUrl) }
    var savedMessageVisible by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var currentLanguage by remember { mutableStateOf(LocaleHelper.currentLanguage()) }

    // PIN lock state
    var pinDialogOpen by remember { mutableStateOf(false) }
    var resetDialogOpen by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = container.backupRepository.exportToJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray())
                    }
                    statusMessage = "Backup saved ✓"
                } catch (e: Exception) {
                    statusMessage = "Backup fail hui: ${e.message}"
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (json != null) {
                        val summary = container.backupRepository.importFromJson(json)
                        statusMessage = "Restore ho gaya: ${summary.customers} customers, ${summary.orders} orders, " +
                            "${summary.payments} payments, ${summary.stockItems} stock items"
                    }
                } catch (e: Exception) {
                    statusMessage = "Restore fail hui: ${e.message}"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Text(stringResource(R.string.settings_shop_details), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = shopName,
            onValueChange = { shopName = it; savedMessageVisible = false },
            label = { Text(stringResource(R.string.settings_shop_name)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = ownerName,
            onValueChange = { ownerName = it; savedMessageVisible = false },
            label = { Text(stringResource(R.string.settings_owner_name)) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(stringResource(R.string.settings_social_media), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            stringResource(R.string.settings_social_media_subtitle),
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = facebookUrl,
            onValueChange = { facebookUrl = it; savedMessageVisible = false },
            label = { Text(stringResource(R.string.settings_facebook_link)) },
            placeholder = { Text("https://facebook.com/yourshop") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
            trailingIcon = {
                if (facebookUrl.isNotBlank()) {
                    TextButton(onClick = { openUrl(context, facebookUrl) }) { Text(stringResource(R.string.settings_open)) }
                }
            }
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = instagramUrl,
            onValueChange = { instagramUrl = it; savedMessageVisible = false },
            label = { Text(stringResource(R.string.settings_instagram_link)) },
            placeholder = { Text("https://instagram.com/yourshop") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.PhotoCamera, contentDescription = null) },
            trailingIcon = {
                if (instagramUrl.isNotBlank()) {
                    TextButton(onClick = { openUrl(context, instagramUrl) }) { Text(stringResource(R.string.settings_open)) }
                }
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                prefs.shopName = shopName.trim()
                prefs.ownerName = ownerName.trim()
                prefs.facebookUrl = facebookUrl.trim()
                prefs.instagramUrl = instagramUrl.trim()
                savedMessageVisible = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(stringResource(R.string.settings_save), style = MaterialTheme.typography.titleMedium)
        }
        if (savedMessageVisible) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(stringResource(R.string.settings_saved), color = MaterialTheme.colorScheme.primary)
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                ThemeMode.DARK_BLUE to stringResource(R.string.theme_dark_blue),
                ThemeMode.WHITE to stringResource(R.string.theme_white),
                ThemeMode.DARK to stringResource(R.string.theme_dark)
            ).forEach { (mode, label) ->
                FilterChip(
                    selected = container.themeMode.value == mode,
                    onClick = {
                        container.themeMode.value = mode
                        prefs.themeMode = mode
                    },
                    label = { Text(label) }
                )
            }
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        // Section 4/17: Language - switches the whole app's language
        // independent of the phone's system language.
        Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.padding(top = 8.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                LocaleHelper.AppLanguage.entries.forEach { language ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        RadioButton(
                            selected = currentLanguage == language,
                            onClick = {
                                currentLanguage = language
                                LocaleHelper.setLanguage(language)
                            }
                        )
                        Text(language.displayName)
                    }
                }
            }
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text(stringResource(R.string.settings_security), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Lock, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                if (prefs.isPinEnabled) stringResource(R.string.security_pin_on) else stringResource(R.string.security_pin_off),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { pinDialogOpen = true }) {
                Text(if (prefs.isPinEnabled) stringResource(R.string.security_change_remove) else stringResource(R.string.security_set_pin))
            }
        }

        if (prefs.isPinEnabled) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Fingerprint, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.security_fingerprint_unlock))
                    if (!biometricAvailable) {
                        Text(
                            stringResource(R.string.security_fingerprint_unavailable),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                Switch(
                    checked = prefs.isFingerprintEnabled && biometricAvailable,
                    enabled = biometricAvailable,
                    onCheckedChange = { prefs.isFingerprintEnabled = it }
                )
            }
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text(stringResource(R.string.settings_notifications), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.notifications_reminder_title))
                Text(
                    stringResource(R.string.notifications_reminder_subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            var remindersOn by remember { mutableStateOf(prefs.remindersEnabled) }
            Switch(
                checked = remindersOn,
                onCheckedChange = {
                    remindersOn = it
                    prefs.remindersEnabled = it
                }
            )
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text(stringResource(R.string.settings_backup), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            stringResource(R.string.backup_subtitle),
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = {
                    val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                    exportLauncher.launch("shop_manager_backup_$dateStr.json")
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.backup_export))
            }
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("application/json")) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.backup_restore))
            }
        }
        statusMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text(
            stringResource(R.string.settings_danger_zone),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.error
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = { resetDialogOpen = true },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.danger_reset_all))
        }
        Spacer(modifier = Modifier.height(24.dp))
    }

    if (pinDialogOpen) {
        PinSetupDialog(
            currentlyEnabled = prefs.isPinEnabled,
            onDismiss = { pinDialogOpen = false },
            onSave = { newPin ->
                prefs.pinCode = newPin
                pinDialogOpen = false
            },
            onRemove = {
                prefs.pinCode = ""
                pinDialogOpen = false
            }
        )
    }

    if (resetDialogOpen) {
        AlertDialog(
            onDismissRequest = { resetDialogOpen = false },
            title = { Text("Reset All Data?") },
            text = { Text("Sabhi customers, orders, payments, aur stock permanently delete ho jayenge. Ye undo nahi ho sakta. Pehle backup lena recommended hai.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        container.backupRepository.resetAllData()
                        statusMessage = "Sara data reset ho gaya"
                        resetDialogOpen = false
                    }
                }) { Text("Reset", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { resetDialogOpen = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PinSetupDialog(
    currentlyEnabled: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
    onRemove: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (currentlyEnabled) "Change PIN" else "Set PIN") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = null },
                    label = { Text("New PIN (4-6 digits)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { confirmPin = it.filter { c -> c.isDigit() }.take(6); error = null },
                    label = { Text("Confirm PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                error?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> error = "Kam se kam 4 digit ka PIN daalein"
                    pin != confirmPin -> error = "PIN match nahi kar raha"
                    else -> onSave(pin)
                }
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (currentlyEnabled) {
                    TextButton(onClick = onRemove) { Text("Remove PIN", color = MaterialTheme.colorScheme.error) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

private fun openUrl(context: android.content.Context, url: String) {
    val normalized = if (url.startsWith("http")) url else "https://$url"
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(normalized)))
}
