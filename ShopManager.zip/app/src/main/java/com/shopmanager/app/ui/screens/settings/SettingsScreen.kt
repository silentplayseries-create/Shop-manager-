package com.shopmanager.app.ui.screens.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.shopmanager.app.AppContainer
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(container: AppContainer) {
    val prefs = container.settingsPrefs
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var shopName by remember { mutableStateOf(prefs.shopName) }
    var ownerName by remember { mutableStateOf(prefs.ownerName) }
    var facebookUrl by remember { mutableStateOf(prefs.facebookUrl) }
    var instagramUrl by remember { mutableStateOf(prefs.instagramUrl) }
    var savedMessageVisible by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    // PIN lock state
    var pinDialogOpen by remember { mutableStateOf(false) }
    var resetDialogOpen by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = container.backupRepository.exportToJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray())
                    }
                    statusMessage = "Backup saved ✓"
                } catch (e: Exception) {
                    statusMessage = "Backup fail hui: ${e.message}"
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (json != null) {
                        val summary = container.backupRepository.importFromJson(json)
                        statusMessage = "Restore ho gaya: ${summary.customers} customers, ${summary.orders} orders, " +
                            "${summary.payments} payments, ${summary.stockItems} stock items"
                    }
                } catch (e: Exception) {
                    statusMessage = "Restore fail hui: ${e.message}"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Text("Shop Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = shopName,
            onValueChange = { shopName = it; savedMessageVisible = false },
            label = { Text("Shop Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = ownerName,
            onValueChange = { ownerName = it; savedMessageVisible = false },
            label = { Text("Owner Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text("Social Media", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            "Ye links customers ko dikhaye ja sakte hain, aur invoice share karte waqt bhi jud sakte hain",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = facebookUrl,
            onValueChange = { facebookUrl = it; savedMessageVisible = false },
            label = { Text("Facebook Page Link") },
            placeholder = { Text("https://facebook.com/yourshop") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
            trailingIcon = {
                if (facebookUrl.isNotBlank()) {
                    TextButton(onClick = { openUrl(context, facebookUrl) }) { Text("Open") }
                }
            }
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = instagramUrl,
            onValueChange = { instagramUrl = it; savedMessageVisible = false },
            label = { Text("Instagram Profile Link") },
            placeholder = { Text("https://instagram.com/yourshop") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.PhotoCamera, contentDescription = null) },
            trailingIcon = {
                if (instagramUrl.isNotBlank()) {
                    TextButton(onClick = { openUrl(context, instagramUrl) }) { Text("Open") }
                }
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                prefs.shopName = shopName.trim()
                prefs.ownerName = ownerName.trim()
                prefs.facebookUrl = facebookUrl.trim()
                prefs.instagramUrl = instagramUrl.trim()
                savedMessageVisible = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Save Settings", style = MaterialTheme.typography.titleMedium)
        }
        if (savedMessageVisible) {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Saved ✓", color = MaterialTheme.colorScheme.primary)
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text("Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dark Blue", modifier = Modifier.weight(1f))
            Switch(
                checked = container.isDarkBlueTheme.value,
                onCheckedChange = {
                    container.isDarkBlueTheme.value = it
                    prefs.isDarkBlueTheme = it
                }
            )
            Text("White")
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text("Security", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Lock, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                if (prefs.isPinEnabled) "PIN Lock: ON" else "PIN Lock: OFF",
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { pinDialogOpen = true }) {
                Text(if (prefs.isPinEnabled) "Change / Remove" else "Set PIN")
            }
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text("Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            "Poora data ek file me save karein, ya pehle se saved file se restore karein.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = {
                    val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                    exportLauncher.launch("shop_manager_backup_$dateStr.json")
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Export")
            }
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("application/json")) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Restore")
            }
        }
        statusMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }

        Divider(modifier = Modifier.padding(vertical = 24.dp))

        Text("Danger Zone", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(
            onClick = { resetDialogOpen = true },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Reset All Data")
        }
        Spacer(modifier = Modifier.height(24.dp))
    }

    if (pinDialogOpen) {
        PinSetupDialog(
            currentlyEnabled = prefs.isPinEnabled,
            onDismiss = { pinDialogOpen = false },
            onSave = { newPin ->
                prefs.pinCode = newPin
                pinDialogOpen = false
            },
            onRemove = {
                prefs.pinCode = ""
                pinDialogOpen = false
            }
        )
    }

    if (resetDialogOpen) {
        AlertDialog(
            onDismissRequest = { resetDialogOpen = false },
            title = { Text("Reset All Data?") },
            text = { Text("Sabhi customers, orders, payments, aur stock permanently delete ho jayenge. Ye undo nahi ho sakta. Pehle backup lena recommended hai.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        container.backupRepository.resetAllData()
                        statusMessage = "Sara data reset ho gaya"
                        resetDialogOpen = false
                    }
                }) { Text("Reset", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { resetDialogOpen = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PinSetupDialog(
    currentlyEnabled: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
    onRemove: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (currentlyEnabled) "Change PIN" else "Set PIN") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = null },
                    label = { Text("New PIN (4-6 digits)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { confirmPin = it.filter { c -> c.isDigit() }.take(6); error = null },
                    label = { Text("Confirm PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
                error?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> error = "Kam se kam 4 digit ka PIN daalein"
                    pin != confirmPin -> error = "PIN match nahi kar raha"
                    else -> onSave(pin)
                }
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (currentlyEnabled) {
                    TextButton(onClick = onRemove) { Text("Remove PIN", color = MaterialTheme.colorScheme.error) }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}

private fun openUrl(context: android.content.Context, url: String) {
    val normalized = if (url.startsWith("http")) url else "https://$url"
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(normalized)))
}
