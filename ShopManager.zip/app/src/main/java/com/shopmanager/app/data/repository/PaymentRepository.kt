package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.CustomerDao
import com.shopmanager.app.data.local.dao.OrderDao
import com.shopmanager.app.data.local.dao.PaymentDao
import com.shopmanager.app.data.local.entity.Payment
import kotlinx.coroutines.flow.Flow

class PaymentRepository(
    private val paymentDao: PaymentDao,
    private val orderDao: OrderDao,
    private val customerDao: CustomerDao
) {

    fun getForCustomer(customerId: Long): Flow<List<Payment>> = paymentDao.getForCustomer(customerId)

    fun getForOrder(orderId: Long): Flow<List<Payment>> = paymentDao.getForOrder(orderId)

    /**
     * Records a part/full payment against an order (Section 9: Payment History).
     * Reduces that order's outstanding balance and reduces the customer's
     * total due by the same amount, while raising total paid.
     */
    suspend fun recordPayment(payment: Payment) {
        paymentDao.insert(payment)

        if (payment.orderId != null) {
            val order = orderDao.getById(payment.orderId)
            if (order != null) {
                val newBalance = (order.balance - payment.amount).coerceAtLeast(0.0)
                orderDao.update(order.copy(balance = newBalance))
            }
        }

        customerDao.applyTotalsDelta(
            customerId = payment.customerId,
            purchaseDelta = 0.0,
            paidDelta = payment.amount,
            dueDelta = -payment.amount
        )
    }
}
