package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.dao.CustomerDao
import com.shopmanager.app.data.local.dao.OrderDao
import com.shopmanager.app.data.local.dao.PaymentDao
import com.shopmanager.app.data.local.entity.Payment
import kotlinx.coroutines.flow.Flow

class PaymentRepository(
    private val paymentDao: PaymentDao,
    private val orderDao: OrderDao,
    private val customerDao: CustomerDao
) {

    fun getAll(): Flow<List<Payment>> = paymentDao.getAll()

    fun getForCustomer(customerId: Long): Flow<List<Payment>> = paymentDao.getForCustomer(customerId)

    fun getForOrder(orderId: Long): Flow<List<Payment>> = paymentDao.getForOrder(orderId)

    /**
     * Records a part/full payment against an order (Section 9: Payment History).
     * Reduces that order's outstanding balance and reduces the customer's
     * total due by the same amount, while raising total paid.
     */
    suspend fun recordPayment(payment: Payment) {
        paymentDao.insert(payment)

        if (payment.orderId != null) {
            val order = orderDao.getById(payment.orderId)
            if (order != null) {
                val newBalance = (order.balance - payment.amount).coerceAtLeast(0.0)
                orderDao.update(order.copy(balance = newBalance))
            }
        }

        customerDao.applyTotalsDelta(
            customerId = payment.customerId,
            purchaseDelta = 0.0,
            paidDelta = payment.amount,
            dueDelta = -payment.amount
        )
    }

    fun getThisMonthTotal(): Flow<Double> {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0)
        val start = cal.timeInMillis
        val end = System.currentTimeMillis()
        return paymentDao.getTotalBetween(start, end)
    }
}
