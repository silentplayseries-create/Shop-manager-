package com.shopmanager.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Staff Module (added per request): basic staff records plus salary info.
 */
@Entity(tableName = "staff")
data class Staff(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val mobile: String,
    val role: String = "",
    val monthlySalary: Double = 0.0,
    val joiningDate: Long = System.currentTimeMillis(),
    val notes: String = ""
)
