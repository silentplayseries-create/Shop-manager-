package com.shopmanager.app.data.repository

import com.shopmanager.app.data.local.AppDatabase
import com.shopmanager.app.data.local.entity.Customer
import com.shopmanager.app.data.local.entity.Order
import com.shopmanager.app.data.local.entity.OrderStatus
import com.shopmanager.app.data.local.entity.Payment
import com.shopmanager.app.data.local.entity.PaymentMode
import com.shopmanager.app.data.local.entity.StockItem
import org.json.JSONArray
import org.json.JSONObject

/**
 * Backup Module (Master Spec Section 16): exports the whole database to a
 * single JSON file the shop owner can save/share, and can restore from one.
 * Restore is destructive (wipes existing data first) - kept simple and
 * predictable rather than attempting a smart merge.
 */
class BackupRepository(private val db: AppDatabase) {

    suspend fun exportToJson(): String {
        val customers = db.customerDao().getAllOnce()
        val orders = db.orderDao().getAllOnce()
        val payments = db.paymentDao().getAllOnce()
        val stockItems = db.stockDao().getAllOnce()

        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val customersArray = JSONArray()
        customers.forEach { c ->
            customersArray.put(JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("mobile", c.mobile)
                put("address", c.address)
                put("notes", c.notes)
                put("totalPurchase", c.totalPurchase)
                put("totalPaid", c.totalPaid)
                put("totalDue", c.totalDue)
                put("createdAt", c.createdAt)
            })
        }
        root.put("customers", customersArray)

        val ordersArray = JSONArray()
        orders.forEach { o ->
            ordersArray.put(JSONObject().apply {
                put("id", o.id)
                put("customerId", o.customerId)
                put("furnitureName", o.furnitureName)
                put("category", o.category)
                put("quantity", o.quantity)
                put("price", o.price)
                put("discount", o.discount)
                put("gstPercent", o.gstPercent)
                put("total", o.total)
                put("advance", o.advance)
                put("balance", o.balance)
                put("deliveryDate", o.deliveryDate ?: JSONObject.NULL)
                put("paymentMode", o.paymentMode.name)
                put("notes", o.notes)
                put("status", o.status.name)
                put("createdAt", o.createdAt)
            })
        }
        root.put("orders", ordersArray)

        val paymentsArray = JSONArray()
        payments.forEach { p ->
            paymentsArray.put(JSONObject().apply {
                put("id", p.id)
                put("customerId", p.customerId)
                put("orderId", p.orderId ?: JSONObject.NULL)
                put("amount", p.amount)
                put("mode", p.mode.name)
                put("note", p.note)
                put("createdAt", p.createdAt)
            })
        }
        root.put("payments", paymentsArray)

        val stockArray = JSONArray()
        stockItems.forEach { s ->
            stockArray.put(JSONObject().apply {
                put("id", s.id)
                put("furnitureName", s.furnitureName)
                put("category", s.category)
                put("buyingPrice", s.buyingPrice)
                put("sellingPrice", s.sellingPrice)
                put("quantity", s.quantity)
                put("minQuantity", s.minQuantity)
                put("supplier", s.supplier)
                put("createdAt", s.createdAt)
            })
        }
        root.put("stockItems", stockArray)

        return root.toString(2)
    }

    /** @return counts of restored records, for a confirmation message. */
    suspend fun importFromJson(json: String): RestoreSummary {
        val root = JSONObject(json)

        val customers = mutableListOf<Customer>()
        val customersArray = root.optJSONArray("customers") ?: JSONArray()
        for (i in 0 until customersArray.length()) {
            val o = customersArray.getJSONObject(i)
            customers.add(
                Customer(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    mobile = o.getString("mobile"),
                    address = o.optString("address", ""),
                    notes = o.optString("notes", ""),
                    totalPurchase = o.optDouble("totalPurchase", 0.0),
                    totalPaid = o.optDouble("totalPaid", 0.0),
                    totalDue = o.optDouble("totalDue", 0.0),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val orders = mutableListOf<Order>()
        val ordersArray = root.optJSONArray("orders") ?: JSONArray()
        for (i in 0 until ordersArray.length()) {
            val o = ordersArray.getJSONObject(i)
            orders.add(
                Order(
                    id = o.getLong("id"),
                    customerId = o.getLong("customerId"),
                    furnitureName = o.getString("furnitureName"),
                    category = o.optString("category", ""),
                    quantity = o.getInt("quantity"),
                    price = o.getDouble("price"),
                    discount = o.optDouble("discount", 0.0),
                    gstPercent = o.optDouble("gstPercent", 0.0),
                    total = o.getDouble("total"),
                    advance = o.optDouble("advance", 0.0),
                    balance = o.getDouble("balance"),
                    deliveryDate = if (o.isNull("deliveryDate")) null else o.getLong("deliveryDate"),
                    paymentMode = runCatching { PaymentMode.valueOf(o.getString("paymentMode")) }.getOrDefault(PaymentMode.CASH),
                    notes = o.optString("notes", ""),
                    status = runCatching { OrderStatus.valueOf(o.getString("status")) }.getOrDefault(OrderStatus.PENDING),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val payments = mutableListOf<Payment>()
        val paymentsArray = root.optJSONArray("payments") ?: JSONArray()
        for (i in 0 until paymentsArray.length()) {
            val o = paymentsArray.getJSONObject(i)
            payments.add(
                Payment(
                    id = o.getLong("id"),
                    customerId = o.getLong("customerId"),
                    orderId = if (o.isNull("orderId")) null else o.getLong("orderId"),
                    amount = o.getDouble("amount"),
                    mode = runCatching { PaymentMode.valueOf(o.getString("mode")) }.getOrDefault(PaymentMode.CASH),
                    note = o.optString("note", ""),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val stockItems = mutableListOf<StockItem>()
        val stockArray = root.optJSONArray("stockItems") ?: JSONArray()
        for (i in 0 until stockArray.length()) {
            val o = stockArray.getJSONObject(i)
            stockItems.add(
                StockItem(
                    id = o.getLong("id"),
                    furnitureName = o.getString("furnitureName"),
                    category = o.optString("category", ""),
                    buyingPrice = o.getDouble("buyingPrice"),
                    sellingPrice = o.getDouble("sellingPrice"),
                    quantity = o.getInt("quantity"),
                    minQuantity = o.optInt("minQuantity", 2),
                    supplier = o.optString("supplier", ""),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        // Clear in FK-safe order (dependents first), then insert in
        // FK-safe order (parents first).
        db.paymentDao().clearAll()
        db.orderDao().clearAll()
        db.customerDao().clearAll()
        db.stockDao().clearAll()

        db.customerDao().insertAll(customers)
        db.orderDao().insertAll(orders)
        db.paymentDao().insertAll(payments)
        db.stockDao().insertAll(stockItems)

        return RestoreSummary(customers.size, orders.size, payments.size, stockItems.size)
    }

    /** Section 17: Settings > Reset - wipes all shop data. Irreversible. */
    suspend fun resetAllData() {
        db.paymentDao().clearAll()
        db.orderDao().clearAll()
        db.customerDao().clearAll()
        db.stockDao().clearAll()
    }
}

data class RestoreSummary(
    val customers: Int,
    val orders: Int,
    val payments: Int,
    val stockItems: Int
)
